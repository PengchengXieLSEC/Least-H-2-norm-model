from pdfo import *
import nevergrad as ng

from SUSD_optimizer import susd_optimizer
from NM_optimizer import nm_optimizer
from GD_optimizer import gd_optimizer

from obj_fun import rosenbrock_grad as obj_grad
from simplex import *

import numpy as np
import matplotlib.pyplot as plt
import math
from alg4.obj_fun import curly30 as obj

from zoopt import Dimension, ValueType, Dimension2, Objective, Parameter, Opt, ExpOpt

from gradient_free_optimizers import *

import csv


MAX_ITER=500

# problem=["rosenbrock", "quadratic", "rastrigin", "square", "arglina", "arglina4", "arglinb", "arglinc"
#          "bdqrtic", "arwhead"]
problem=["arglina","arglina4","arglinb","arglinc","argtrig","arwhead","bdqrtic","bdqrticp","bdvalue","brownal","broydn3d","broydn7d","brybnd","chainwoo","chebquad","chnrosnb","chpowellb","chpowells","chrosen","cosine","cragglvy","cube","curly10","curly20","curly30","dixmaane","dixmaanf","dixmaang","dixmaanh","dixmaani","dixmaanj","dixmaank","dixmaanl","dixmaanm","dixmaann","dixmaano","dixmaanp","dqrtic","edensch","eg2","engval1","errinros","expsum","extrosnb","exttet","firose","fletcbv2","fletcbv3","fminsrf2","fletchcr","freuroth","genbrown","genhumps","genrose","indef","integreq","liarwhd","lilifun3","lilifun4","morebv","morebvl","ncb20","ncb20b","noncvxu2","noncvxun","nondia","nondquar","penalty1","penalty2","penalty3","penalty3p","powellsg","power","rosenbrock","sbrybnd","sbrybndl","schmvett","scosine","scosinel","serose","sinquad","sphrpts","sparsine","sparsqur","spmsrtls","srosenbr","stmod","tointgss","tointtrig","tquartic","trigsabs","trigssqs","trirose1","trirose2","vardim","woods"]
    
#sig = [0,1,2,3,4]
sig = [0]
flag_TR = [0,1]
flag_map = [28,44]#0-48
flag_model = [0]#0:linear,1:quadratic
flag_figure = 1#1:NF 0:iteration
Index=[]#跳过的问题的编号
frec=np.zeros((len(problem),len(sig)*len(flag_TR)*len(flag_map)*len(flag_model)+4,MAX_ITER))

for i_problem in range(len(problem)):
    #if i_problem>=0:
    try:
        if i_problem == 0:
            from obj_fun import arglina as obj
        if i_problem == 1:
            from obj_fun import arglina4 as obj
        if i_problem == 2:
            from obj_fun import arglinb as obj
        if i_problem == 3:
            from obj_fun import arglinc as obj    
        if i_problem == 4:
            from obj_fun import arglinc as obj
        if i_problem == 5:
            from obj_fun import arwhead as obj
        if i_problem == 6:
            from obj_fun import bdqrtic as obj
        if i_problem == 7:
            from obj_fun import bdqrticp as obj  
        if i_problem == 8:
            from obj_fun import bdvalue as obj
        if i_problem == 9:
            from obj_fun import brownal as obj
        if i_problem == 10:
            from obj_fun import broydn3d as obj        
        if i_problem == 11:
            from obj_fun import broydn7d as obj        
        if i_problem == 12:
            from obj_fun import brybnd as obj        
        if i_problem == 13:
            from obj_fun import chainwoo as obj        
        if i_problem == 14:
            from obj_fun import chebquad as obj        
        if i_problem == 15:
            from obj_fun import chnrosnb as obj        
        if i_problem == 16:
            from obj_fun import chpowellb as obj        
        if i_problem == 17:
            from obj_fun import chpowells as obj        
        if i_problem == 18:
            from obj_fun import chrosen as obj        
        if i_problem == 19:
            from obj_fun import cosine as obj        
        if i_problem == 20:
            from obj_fun import cragglvy as obj        
        if i_problem == 21:
            from obj_fun import cube as obj        
        if i_problem == 22:
            from obj_fun import curly10 as obj        
        if i_problem == 23:
            from obj_fun import curly20 as obj        
        if i_problem == 24:
            from obj_fun import curly30 as obj        
        if i_problem == 25:
            from obj_fun import dixmaane as obj        
        if i_problem == 26:
            from obj_fun import dixmaanf as obj        
        if i_problem == 27:
            from obj_fun import dixmaang as obj        
        if i_problem == 28:
            from obj_fun import dixmaanh as obj        
        if i_problem == 29:
            from obj_fun import dixmaani as obj        
        if i_problem == 30:
            from obj_fun import dixmaanj as obj        
        if i_problem == 31:
            from obj_fun import dixmaank as obj        
        if i_problem == 32:
            from obj_fun import dixmaanl as obj        
        if i_problem == 33:
            from obj_fun import dixmaanm as obj        
        if i_problem == 34:
            from obj_fun import dixmaann as obj        
        if i_problem == 35:
            from obj_fun import dixmaano as obj        
        if i_problem == 36:
            from obj_fun import dixmaanp as obj        
        if i_problem == 37:
            from obj_fun import dqrtic as obj        
        if i_problem == 38:
            from obj_fun import edensch as obj        
        if i_problem == 39:
            from obj_fun import eg2 as obj        
        if i_problem == 40:
            from obj_fun import engval1 as obj        
        if i_problem == 41:
            from obj_fun import errinros as obj        
        if i_problem == 42:
            from obj_fun import expsum as obj        
        if i_problem == 43:
            from obj_fun import extrosnb as obj        
        if i_problem == 44:
            from obj_fun import exttet as obj        
        if i_problem == 45:
            from obj_fun import firose as obj        
        if i_problem == 46:
            from obj_fun import fletcbv2 as obj        
        if i_problem == 47:
            from obj_fun import fletcbv3 as obj        
        if i_problem == 48:
            from obj_fun import fminsrf2 as obj        
        if i_problem == 49:
            from obj_fun import fletchcr as obj        
        if i_problem == 50:
            from obj_fun import freuroth as obj        
        if i_problem == 51:
            from obj_fun import genbrown as obj        
        if i_problem == 52:
            from obj_fun import genhumps as obj        
        if i_problem == 53:
            from obj_fun import genrose as obj        
        if i_problem == 54:
            from obj_fun import indef as obj        
        if i_problem == 55:
            from obj_fun import integreq as obj        
        if i_problem == 56:
            from obj_fun import liarwhd as obj        
        if i_problem == 57:
            from obj_fun import lilifun3 as obj        
        if i_problem == 58:
            from obj_fun import lilifun4 as obj        
        if i_problem == 59:
            from obj_fun import morebv as obj        
        if i_problem == 60:
            from obj_fun import morebvl as obj        
        if i_problem == 61:
            from obj_fun import ncb20 as obj        
        if i_problem == 62:
            from obj_fun import ncb20b as obj        
        if i_problem == 63:
            from obj_fun import noncvxu2 as obj        
        if i_problem == 64:
            from obj_fun import noncvxun as obj        
        if i_problem == 65:
            from obj_fun import nondia as obj        
        if i_problem == 66:
            from obj_fun import nondquar as obj        
        if i_problem == 67:
            from obj_fun import penalty1 as obj        
        if i_problem == 68:
            from obj_fun import penalty2 as obj        
        if i_problem == 69:
            from obj_fun import penalty3 as obj        
        if i_problem == 70:
            from obj_fun import penalty3p as obj        
        if i_problem == 71:
            from obj_fun import powellsg as obj        
        if i_problem == 72:
            from obj_fun import power as obj        
        if i_problem == 73:
            from obj_fun import rosenbrock as obj        
        if i_problem == 74:
            from obj_fun import sbrybnd as obj        
        if i_problem == 75:
            from obj_fun import sbrybndl as obj        
        if i_problem == 76:
            from obj_fun import schmvett as obj        
        if i_problem == 77:
            from obj_fun import scosine as obj        
        if i_problem == 78:
            from obj_fun import scosinel as obj        
        if i_problem == 79:
            from obj_fun import serose as obj        
        if i_problem == 80:
            from obj_fun import sinquad as obj        
        if i_problem == 81:
            from obj_fun import sphrpts as obj        
        if i_problem == 82:
            from obj_fun import sparsine as obj        
        if i_problem == 83:
            from obj_fun import sparsqur as obj        
        if i_problem == 84:
            from obj_fun import spmsrtls as obj        
        if i_problem == 85:
            from obj_fun import srosenbr as obj        
        if i_problem == 86:
            from obj_fun import stmod as obj        
        if i_problem == 87:
            from obj_fun import tointgss as obj        
        if i_problem == 88:
            from obj_fun import tointtrig as obj        
        if i_problem == 89:
            from obj_fun import tquartic as obj        
        if i_problem == 90:
            from obj_fun import trigsabs as obj        
        if i_problem == 91:
            from obj_fun import trigssqs as obj        
        if i_problem == 92:
            from obj_fun import trirose1 as obj        
        if i_problem == 93:
            from obj_fun import trirose2 as obj        
        if i_problem == 94:
            from obj_fun import vardim as obj        
        if i_problem == 95:
            from obj_fun import woods as obj        
    
        # create SUSD optimizer with objective function
        #susd_opt = susd_optimizer(obj, alpha=0.5, max_iter=10000) #7E-3
        
        # create GD optimizer with objective function and gradient function
        #gd_opt = gd_optimizer(obj, obj_grad, alpha=1E-1, max_iter=50)
        
        #create Nelder-Mead optimizer with objective function
        nm_opt = nm_optimizer(obj, max_iter=MAX_ITER)
        
        N =  10
        count_algorithm=0
        xinit = 5*np.ones([N, 1])
        
        Nagents_0 = N+2
        X0_0=5*np.random.rand(N,Nagents_0)
        #Fx0_0=obj(X0_0)
        ###################################
        n=X0_0.shape
        Fx0_0=np.zeros((1,n[1]))
        Fx0_0=Fx0_0[0]
        for i in range(n[1]):
            Fx0_0[i]=obj(X0_0[:,i])
        ###################################
            
        idmin_x0_0=np.argmin(Fx0_0)
        Nagents_1 = int((N**2+3*N+4)/2)
        X0_1=5*np.random.rand(N,Nagents_1)
        #Fx0_1=obj(X0_1)
        ###################################
        n=X0_1.shape
        Fx0_1=np.zeros((1,n[1]))
        Fx0_1=Fx0_1[0]
        for i in range(n[1]):
            Fx0_1[i]=obj(X0_1[:,i])
        ###################################   
        
        idmin_x0_1=np.argmin(Fx0_1)
        
        if Fx0_0[idmin_x0_0]>Fx0_1[idmin_x0_1]:
            X0_0[:,idmin_x0_0]=X0_1[:,idmin_x0_1]
        else:
            X0_1[:,idmin_x0_1]=X0_0[:,idmin_x0_0]
        
        fig = plt.figure()
        
        f = []
        leg = []
        for ids_sig in range(len(sig)):
            for ids_TR in range(len(flag_TR)):
                for ids_map in range(len(flag_map)):
                    for ids_model in range(len(flag_model)):
                        count_algorithm=count_algorithm+1
                        # create SUSD optimizer with objective function
                        susd_opt = susd_optimizer(obj, alpha=0.8, max_iter=MAX_ITER, sig=sig[ids_sig], flag_TR=flag_TR[ids_TR], flag_map=flag_map[ids_map], flag_model=flag_model[ids_model]) #7E-3
        
                        # find optimal x from an initial guess
                        if flag_model[ids_model] == 0:
                            x0=X0_0
                        if flag_model[ids_model] == 1:
                            x0=X0_1
                        # x0 = 0.5*np.random.rand(N,Nagentsxinit
                            
                        # search
                        susd_it, susd_hist = susd_opt.search(x0, term_len=10)#终止条件
        
                    
                        f = np.zeros(susd_it)
                        for it in range(susd_it):
                            f[it] = susd_hist[it][2]
                        # print("F+++++FFFFFFFFFFFFFFFFFFFFF+++++++++")
                        # print(f[0])
        
                        
                        
                        if flag_model[ids_model]==0:
                            if flag_figure == 0:
                                ff=np.zeros((1,len(f)))
                                for i in range(len(f)):
                                    ff[0,i:(i+1)]=f[i]*np.ones((1,1))
                            if flag_figure == 1:
                                ff=np.zeros((1,Nagents_0*len(f)))
                                for i in range(len(f)):
                                    ff[0,i*Nagents_0:(i+1)*Nagents_0]=f[i]*np.ones((1,Nagents_0))
                        if flag_model[ids_model]==1:
                            if flag_figure == 0:
                                ff=np.zeros((1,len(f)))
                                for i in range(len(f)):
                                    ff[0,i:(i+1)]=f[i]*np.ones((1,1))
                            if flag_figure == 1:
                                ff=np.zeros((1,Nagents_1*len(f)))
                                for i in range(len(f)):
                                    ff[0,i*Nagents_1:(i+1)*Nagents_1]=f[i]*np.ones((1,Nagents_1))
                    
                        if len(ff[0,:])>=MAX_ITER:
                            frec[i_problem,count_algorithm-1,0:MAX_ITER]=ff[0,0:MAX_ITER]
                        else:
                            frec[i_problem,count_algorithm-1,0:len(ff[0,:])]=ff[0,:]
                            #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
                            FFF=f[-1]*np.ones((1,MAX_ITER-len(ff[0,:])))
                            FFF=np.array(FFF)
                            frec[i_problem,count_algorithm-1,len(ff[0,:]):len(ff[0,:])+len(FFF[0])]=FFF
                       
                        
                        plt.plot(frec[i_problem,count_algorithm-1,:], '-')
                        leg.append("Sig="+str(sig[ids_sig])+' '+"Flag_TR="+str(flag_TR[ids_TR])+' '+"Flag_map="+str(flag_map[ids_map])+' '+"Flag_model="+str(flag_model[ids_model]))
        
        ###############################################
        # find optimal x from an initial guess
        #x = 0.5*np.random.rand(N, 1) + xinit
        
        # search
        #gd_it, gd_hist = gd_opt.search(x, term_grad=0.1)
        
        #print "GD search took", gd_it, "iterations"
        #print "fmin:", gd_hist[gd_it][1]
        
        
        # find optimal x from an initial guess using NM
        #xstep = np.tril(10*np.ones((N, N)))
        #x0 = np.hstack((xinit, xinit+xstep))
        
        # search
        x00=x0[:,0:N+1]
        x00[:,0]=X0_0[:,idmin_x0_0]
        nm_it, nm_hist = nm_opt.search(x00, term_dev=0.01)
        
        
        
        # show the results
        #f = np.zeros(susd_it)
        #for it in range(susd_it):  
        #    f[it] = susd_hist[it][2]
        
        #plt.plot(f, '-')
        
        #f = np.zeros(gd_it)
        #for it in range(gd_it):  
        #    f[it] = gd_hist[it][1]
        
        #plt.plot(f, '-')
        
        count_algorithm=count_algorithm+1
        
        if nm_it==0:
            nm_it=1
        f = np.zeros(nm_it)
        for it in range(nm_it):  
            f[it] = nm_hist[it][1]
        
        print("*********************problem*****************")
        print(i_problem)
        # print(nm_it)
        A=frec[i_problem,count_algorithm-1,N+1:len(f)+N+1]
        # print(A.shape)
        # print(f.shape)
        # print(len(A))
        if flag_figure==1:
            frec[i_problem,count_algorithm-1,N+1:len(f)+N+1]=f[0:len(A)]
            frec[i_problem,count_algorithm-1,0:N+1]=f[0]*np.ones((1,N+1))
            if (len(f)+N+1)<MAX_ITER:
            #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
                FFF=f[-1]*np.ones((1,MAX_ITER-len(f)-(N+1)))
                FFF=np.array(FFF)
                frec[i_problem,count_algorithm-1,len(f)+N+1:len(f)+N+1+len(FFF[0])]=FFF
        if flag_figure==0:
            frec[i_problem,count_algorithm-1,0:len(f)]=f
            if len(f)<MAX_ITER:
                frec[i_problem,count_algorithm-1,len(f):-1]=np.ones((1,MAX_ITER-len(f)))*f[-1]
        
        plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        leg.append("Nelder-Mead")
        
        
        #########################################
        dim_size=N
        dim = Dimension(dim_size, [[-1, 1]]*dim_size, [True]*dim_size)  # dim = Dimension2([(ValueType.CONTINUOUS, [-1, 1], 1e-6)]*dim_size)
        Obj = Objective(obj, dim)
        print("0000000000000000000000000")
        # perform optimization
        solution = Opt.min(Obj, Parameter(budget=MAX_ITER))
        print("0000000000000000000000000")
        # print the solution
        #print(solution.get_x(), solution.get_value())
        # parallel optimization for time-consuming tasks
        #solution = Opt.min(obj, Parameter(budget=100*dim_size, parallel=True, server_num=3))

        #plt.plot(Obj.get_history_bestsofar(),'-')
        
        
        count_algorithm=count_algorithm+1

        f=Obj.get_history_bestsofar()
        frec[i_problem,count_algorithm-1,0:len(f)]=f
        if len(f)<MAX_ITER:
        #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
            FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
            FFF=np.array(FFF)
            frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
        
        plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        leg.append("Zoopt")
        #########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # opt = RandomSearchOptimizer(search_space)
        # opt.search(ackley_function, n_iter=MAX_ITER)
        
        #########################################
        optimizer = ng.optimizers.NGOpt(parametrization=N, budget=MAX_ITER)
        recommendation = optimizer.minimize(obj)
        #print(recommendation)  # recommended value
        #print(F)
        f=open('A.csv','r',encoding='utf-8')
        reader=csv.reader(f)
        A=list(reader)
        A=np.array(A)
        A=np.float64(A)
        #print(A)
        
        count_algorithm=count_algorithm+1

        f=A[0]
        frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        print(f)
        if len(f)<MAX_ITER:
        #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
            FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
            FFF=np.array(FFF)
            frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
        plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        leg.append("NGopt")
        ########################**********RandomSearchOptimizer***************###########################
        # # NO.1 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = RandomSearchOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("RandomSearchOptimizer")
        # #########################################
        
        # # NO.2 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = HillClimbingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
            
        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]

        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("HillClimbingOptimizer")
        #########################################
        
        # # NO.3 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = StochasticHillClimbingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("StochasticHillClimbingOptimizer")
        # #########################################
        
        # # NO.4 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = RepulsingHillClimbingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("RepulsingHillClimbingOptimizer")
        # #########################################
        
        # # NO.5 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = SimulatedAnnealingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("SimulatedAnnealingOptimizer")
        # #########################################
        
        # # NO.6 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = DownhillSimplexOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("DownhillSimplexOptimizer")
        # #########################################
        
        # # NO.7 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = RandomRestartHillClimbingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("RandomRestartHillClimbingOptimizer")
        #########################################
        
        # # NO.8 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = RandomAnnealingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("RandomAnnealingOptimizer")
        # #########################################
        
        # # NO.9 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = ParallelTemperingOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("ParallelTemperingOptimizer")
        # ########################################
        
        # # NO.10 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = ParticleSwarmOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            


        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("ParticleSwarmOptimizer")
        # #########################################
        
        # # NO.11 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = EvolutionStrategyOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("EvolutionStrategyOptimizer")
        #########################################
        
        # # NO.12 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = BayesianOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # frec[i_problem,count_algorithm-1,:]=-frec[i_problem,count_algorithm-1,:]
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("BayesianOptimizer")
        # ########################################
        
        # # NO.13 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = TreeStructuredParzenEstimators(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("TreeStructuredParzenEstimators")
        # #########################################
        
        # # NO.14 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = DecisionTreeOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("DecisionTreeOptimizer")
        # ########################################
        
        # # NO.15 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {} 
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = PowellsMethod(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("PowellsMethod")
        # #########################################
        
        # # NO.16 ########################################
        
        # search_space = {
        #     "x1": np.arange(-100, 101, 0.1),
        #     "x2": np.arange(-100, 101, 0.1),
        #     "x3": np.arange(-100, 101, 0.1),
        #     "x4": np.arange(-100, 101, 0.1),
        #     "x5": np.arange(-100, 101, 0.1),
        #     }

        # # opt = RandomSearchOptimizer(search_space)
        # # opt.search(ackley_function, n_iter=30000)

        # # create initial positions
        # warm_start1 = {}
        # warm_start2 = {}
        # for i in range(N):
        #     warm_start1["x"+str(i+1)]=X0_0[i,idmin_x0_0]
        #     warm_start2["x"+str(i+1)]=X0_0[i,0]
        
        
        # # add initial positions to initialize- dictionary
        # initialize = {"warm_start": [warm_start1, warm_start2]}
        # opt = EnsembleOptimizer(search_space, initialize=initialize) 
        # opt.search(obj, n_iter=MAX_ITER)
        # # get the results data from the optimization run
        # search_data = opt.results
        # #print("\n search_data \n", search_data)
        
        # count_algorithm=count_algorithm+1

        # f=search_data.score
        # frec[i_problem,count_algorithm-1,0:len(f)]=f[:]
        # if len(f)<MAX_ITER:
        # #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
        #     FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
        #     FFF=np.array(FFF)
        #     frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
            
        # plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        
        # leg.append("EnsembleOptimizer")
        # #########################################
        ########################**********RandomSearchOptimizer***************###########################
        
        #########################################
        # SimplexSearch_opt = SimplexSearch(obj,x00, max_iterations=MAX_ITER, ftol=1.0e-6)
        # S=SimplexSearch_opt.run()
       #  fff=[]
       #  optimizer = ng.optimizers.NGOpt(parametrization=N, budget=100)
       #  # def square(x):
       #  #     return sum((x - .5)**2)
       #  recommendation = optimizer.minimize(obj)
       # # print(recommendation.kwargs)  # recommended value
        #########################################
        
        count_algorithm=count_algorithm+1
        
        options = {'maxfev': MAX_ITER}
        x=pdfo(obj,X0_0[:,idmin_x0_0], options=options)
        f=x.fhist
        frec[i_problem,count_algorithm-1,0:len(f)]=f
        if len(f)<MAX_ITER:
        #FFF=frec[i_problem,count_algorithm-1,len(f)-1:-1]
            FFF=f[-1]*np.ones((1,MAX_ITER-len(f)))
            FFF=np.array(FFF)
            frec[i_problem,count_algorithm-1,len(f):len(f)+len(FFF[0])]=FFF
        
        plt.plot(frec[i_problem,count_algorithm-1,:], '-')
        leg.append("Pdfo")
        if i_problem == 0:
            plt.plot(np.zeros(susd_it)+100, 'k--')
            leg.append("Rosenbrock Minimum")
        
        plt.title(problem[i_problem]+ "("+str(N)+" dim)")
        plt.ylabel("f(x)")
        if flag_figure == 0:
            plt.xlabel("Iteration")
        if flag_figure == 1:
            plt.xlabel("NF")
        #plt.legend(["SUSD ("+str(Nagents)+" agents)", "Rosenbrock Minimum"])
        plt.legend(leg,loc=3,bbox_to_anchor=(1.05,0),borderaxespad = 0)
        plt.grid()
        plt.draw()
        plt.xlim([0,150])
        plt.show()
        fig.savefig('myfigure'+str(i_problem)+'.eps', dpi=300, bbox_inches = 'tight')
        
    except:
        Index.append(i_problem)        
        
        

########################################################
frec=np.delete(frec, Index, axis=0)
########################################################
########################################################
n=frec.shape
print(n)

fmin=np.zeros((n[0],1))
for i_problem in range(n[0]):
    print("++++++++++++++++++++++++++")
    A=(frec[i_problem,:,:])
    fmin[i_problem]=min(np.min(A,axis=1))
        

        
        
    ################################################
    ################################################
    ################################################
    
    
    
    
    

    
    
    
    
    
    ################################################
    ################################################
    ################################################
    
    
tau=0.01

T=np.zeros((n[0],n[1]))
f0=-math.inf*np.ones((n[0],1))
for i_problem in range(n[0]):
    f0[i_problem]=frec[i_problem,0,0]
    
f_acc=np.zeros((n[0],n[1]))
for i_problem in range(n[0]):
    for i_solver in range(n[1]):
        if min(frec[i_problem,i_solver,:]) <= (tau*f0[i_problem] + (1 - tau)*fmin[i_problem])[0]:
            fir=[i for i in range(MAX_ITER) if (frec[i_problem,i_solver,i]<=tau*f0[i_problem] + (1 - tau)*fmin[i_problem])]
            T[i_problem,i_solver]=fir[0]

            f_acc[i_problem,i_solver]=(frec[i_problem,i_solver,int(T[i_problem,i_solver])] - f0[i_problem]) / (fmin[i_problem] - f0[i_problem])
        else:
            T[i_problem,i_solver]=math.inf
    

    
delsame=0
fontsize=16
linewidth=2
penalty=2

if (n[0] == 0):
    T=np.ones((1,n[1]))
    np=1
    
r=np.zeros((n[0],n[1]))
Tmin=np.min(T,axis=1)
for i_problem in range(n[0]):
    if math.isinf(Tmin[i_problem])==0:
        r[i_problem,:]=(T[i_problem,:]+1)/(Tmin[i_problem]+1)

r=np.log2(r)

for i_problem in range(n[0]):
    for i_solver in range(n[1]):
        if math.isinf(r[i_problem,i_solver])==1:
            r[i_problem,i_solver]=9999
            
m=np.max(r,axis=0)
max_ratio=max(1.0e-6,max(m))
for i_problem in range(n[0]):
    for i_solver in range(n[1]):
        if math.isinf(r[i_problem,i_solver]):
            r[i_problem,i_solver]=penalty*max_ratio
r=np.sort(r,axis=0)
    

fig=plt.figure()
plt.title("Perf Profile")
plt.ylabel(r"$\pi_s(\alpha)$")
plt.xlabel(r"$\log_2(\alpha), \quad \alpha = \mathrm{NF}/\mathrm{NF}_{\min}$")
plt.xlim([0,5])
for i_solver in range(n[1]):
    xs=r[:,i_solver]
    ys=np.arange(1,n[0]+1,1)/n[0]
    xs[-1]=9999
    plt.step(xs, ys, lw=2)

plt.legend(leg,loc=3,bbox_to_anchor=(1.05,0),borderaxespad = 0)    
plt.grid()
plt.draw()
plt.show()
fig.savefig('Perf.eps', dpi=300, bbox_inches = 'tight')
 




D=np.zeros((n[1],int(1.2*MAX_ITER)))
for i_solver in range(n[1]):
    for i_MAX_ITER in range(MAX_ITER):
        fir=[i_problem for i_problem in range(n[0]) if T[i_problem,i_solver]<=i_MAX_ITER]
        D[i_solver,i_MAX_ITER]=len(fir) / n[0]
    A=np.arange(MAX_ITER, 1.2*MAX_ITER, 1)
    A=np.floor(A)
    A=A.astype(np.int)
    for i_MAX_ITER in A:
        D[i_solver,i_MAX_ITER]=D[i_solver,MAX_ITER-1]
fig=plt.Figure()
plt.title("Data Profile")
plt.ylabel(r"$\delta_s(\beta)$")
plt.xlabel(r"$\beta = \mathrm{NF}/(n+1)$")  
for i_solver in range(n[1]):
    xs=np.arange(0, 1.2*MAX_ITER, 1)/(N+1)
    ys=D[i_solver,:]
    plt.step(xs, ys, lw=2)

plt.legend(leg,loc=3,bbox_to_anchor=(1.05,0),borderaxespad = 0)
plt.grid()
plt.draw()
plt.show()
fig.savefig('Data.eps', dpi=300, bbox_inches = 'tight')


print(leg)  

fig=plt.figure()
plt.title("Data Profile")
plt.ylabel(r"$\delta_s(\beta)$")
plt.xlabel(r"$\beta = \mathrm{Iteration}/(n+1)$")  
for i_solver in range(n[1]):
    xs=np.arange(0, 1.2*MAX_ITER, 1)/(N+1)
    ys=D[i_solver,:]
    plt.step(xs, ys, lw=2)

plt.legend(leg,loc=3,bbox_to_anchor=(1.05,0),borderaxespad = 0)
plt.grid()
plt.draw()
plt.show()
fig.savefig('Data.eps', dpi=300, bbox_inches = 'tight')