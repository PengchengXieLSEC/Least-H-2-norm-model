"""
Description:
An implementation of the DFO algorithm developed by A. Conn,
K. Scheinberg, L. Vicente
"""
import numpy as np
from functools import reduce
import math
from scipy import linalg as LA

def _compute_coeffs(W, tol_svd, b, option):
    """Compute model coefficients -- Here we are merely solving the
     system of equations -- decompose W and use its inverse
    """
    if option == 'partial':
        U, S, VT = LA.svd(W)
    else:
        U, S, VT = LA.svd(W, full_matrices=False)

    # Make sure the condition number is not too high
    indices = S < tol_svd
    S[indices] = tol_svd
    Sinv = np.diag(1/S)
    V = VT.T
    # Get the coefficients
    lambda_0 = reduce(np.dot, [V, Sinv, U.T, b])
    return (lambda_0)

def quad_Frob(X, F_values, args):
    """
    Given a set of points in the trust region
    and their values, construct a quadratic model
    in the form of g.T x + 1/2 x.T H x + \alpha.

    If the number of points are less than
    (n+1) (n+2)/2 then build the model such that the
    Frobenius norm is minimized. In this code the KKT
    conditions are solved. Otherwise, solve
    the system of equations used in polynomial interpolation.
    M(\phi, Y) \lambda = f

    arguments: X: the sample points to be interpolated
        F_values: the corresponding true solutions to the sample points
    outputs: g and H in the quadratic model
    """
    # Minimum value accepted for a singular value
    eps = np.finfo(float).eps
    tol_svd = eps**5
    # n = number of variables m = number of points
    (n, m) = X.shape

    H = np.zeros((n, n))
    g = np.zeros((n, 1))

    # Shift the points to the origin
    Y = X - np.dot(np.diag(X[:, 0]), np.ones((n, m)))

    if (m < (n+1)*(n+2)/2):
        c1 = args.c1
        c2 = args.c2
        c3 = args.c2
        r = 1
        V2 = (np.pi**(n/2)/math.gamma(n/2+1))
        omega1 = V2*r**n*(c1*r**4/(2*(n+4)*(n+2))+c2*r**2/(n+2)+c3)
        omega2 = V2*r**n*(c1*r**2/(n+2)+c2)
        omega3 = c1*V2*r**(n+4)/(4*(n+4)*(n+2))
        omega4 = c1*V2*r**(n+2)/(n+2)
        omega5 = c1*V2*r**n
        # Construct a quad model by minimizing the Frobenius norm of
        # the Hessian -- the following is the solution of the KKT conditions
        # of the optimization problem on page 81 of the Intro to DFO book
        b = np.vstack((F_values, np.zeros((n+2, 1))))
        A = 1/(8*omega1) * (np.dot(Y.T, Y)**2)
        J = np.zeros((m,1))
        X_bar = np.zeros((1,m))
        B1 = np.zeros((1,m))
        for i in range(m):
            J[i] = 1 - omega4/(4*omega1)*np.dot(Y[:,i].T,Y[:,i])
            X_bar[0,i] = -omega3/(2*omega1)*np.dot(Y[:,i].T,Y[:,i])
            B1[0,i] = 0.5*np.dot(Y[:,i].T,Y[:,i])

        # Construct W by augmenting the vector of ones with the linear and
        # quadratic terms. The first m rows build the matrix M, which is
        # introduced in the slides (monomials of quadratic basis)
        line1 = np.hstack((A, np.ones((m, 1)), Y.T, X_bar.T))
        line2 = np.hstack((np.ones((1,m)), -2*omega5*np.ones((1,1)), np.zeros((1,n)), -omega4*np.ones((1,1))))
        line3 = np.hstack((Y, np.zeros((n,1)), -2*omega2*np.identity(n), np.zeros((n,1))))
        line4 = np.hstack((B1, -n*omega4*np.ones((1,1)), np.zeros((1,n)), (-2*n*omega3-2*omega1)*np.ones((1,1))))
        W = np.vstack((line1,line2,line3,line4))
        lambda_0 = _compute_coeffs(W, tol_svd, b, option='partial')

        # Grab the coeffs of linear terms (g) and the ones of quadratic terms
        # (H) for g.T s + s.T H s
        c = lambda_0[m:m+1]
        g = lambda_0[m+1:m+1+n]
        T = lambda_0[m+1+n]
        

        H = np.zeros((n, n))
        for j in range(m):
            H = H + 1/(4*omega1)*(lambda_0[j] *
                    np.dot(Y[:, j].reshape(n, 1), Y[:, j].reshape(1, n)) 
                    - (2*omega3*T+omega4*c)*np.identity(n))

    else:  # Construct a full model
        # Here we have enough points. Solve the sys of equations.
        b = F_values
        phi_Q = np.array([])
        for i in range(m):
            y = Y[:, i]
            y = y[np.newaxis]  # turn y from 1D to a 2D array
            aux_H = y * y.T - 0.5 * np.diag(pow(y, 2)[0])
            aux = np.array([])
            for j in range(n):
                aux = np.hstack((aux, aux_H[j:n, j]))

            phi_Q = np.vstack((phi_Q, aux)) if phi_Q.size else aux

        W = np.hstack((np.ones((m, 1)), Y.T))
        W = np.hstack((W, phi_Q))

        lambda_0 = _compute_coeffs(W, tol_svd, b, option='full')

        # Retrieve the model coeffs (g) and (H)
        g = lambda_0[1:n+1, :]
        cont = n+1
        H = np.zeros((n, n))

        for j in range(n):
            H[j:n, j] = lambda_0[cont:cont + n - j, :].reshape((n-j,))
            cont = cont + n - j

        H = H + H.T - np.diag(np.diag(H))
    return (H, g)
