import numpy as np
import math
from alg1 import obj_fun
from inspect import isfunction
from zoopt import Dimension, ValueType, Dimension2, Objective, Parameter, Opt, ExpOpt
from alg1.bb_optimize import lengthOfVector
#from run_test_func import iterationPoint, valueOfIterationPoint

"""
    objective functions must map from R^{M x N} to R^{N} where M is length of x
    and N is number of SUSD agents/samples to take
"""



def quadratic(x):
    dict_func['quadratic'][0].append(x)
    dict_func['quadratic'][1].append(np.linalg.norm(x,axis=0)**2 + 100)
    return np.linalg.norm(x,axis=0)**2 + 100



countRastrigin =0 
def rastrigin(x):
    global countRastrigin
    countRastrigin += 1 
    A = 0.1
    M = x.shape[0]
    acos = A*np.cos(2*np.pi*x)
    xi_diff = x**2 - acos
    dict_func['rastrigin'][0].append(x)
    dict_func['rastrigin'][1].append(0*A*M + np.sum(xi_diff, axis=0) + 100)
    return 0*A*M + np.sum(xi_diff, axis=0) + 100


countSquare = 0
def square(x):
    global countSquare
    countSquare+=1
    dict_func['square'][0].append(x)
    dict_func['square'][1].append(sum((x + 1)**2)+1)
    return sum((x - .5)**2)+1

########

countArglina =0
def arglina(x):
    global countArglina
    countArglina +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    # print("xxxxxxxxxxxxxxxxxxxxxxxxx")
    # print(x)
    n=len(x)
    m=int(2*n)
    tmp=0
    for i in range(n):
        tmp=tmp+x[i]
    f=0
    for i in range(n):
        f=f+(x[i]-2/m*tmp-1)**2
    for i in range(n):
        f=f+(-2/m*tmp-1)**2
    dict_func['arglina'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['arglina'][1].append(-f)
        return -f
    else:
        dict_func['arglina'][1].append(f)
        return f

        
countArglinb = 0
def arglinb(x):
    global countArglinb
    countArglinb +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=int(2*n)
    tmp=0
    for i in range(n):
        tmp=tmp+(i+1)*x[i]**2
    f=0
    for i in range(n):
        f=f+((i+1)*tmp-1)**2
    for i in range(m):
        f=f+((i+1)*tmp-1)**2
    dict_func['arglinb'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['arglinb'][1].append(-f)
        return -f
    else:
        dict_func['arglinb'][1].append(f)
        return f
        

countBdqrtic = 0
def bdqrtic(x):
    global countBdqrtic
    countBdqrtic+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-4):
        f=f+(x[i]**2+2*x[i+1]**2+3*x[i+2]**2+4*x[i+3]**2+5*x[-1]**2)**2+(-4*x[i]+3)**2
    dict_func['bdqrtic'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdqrtic'][1].append(-f)
        return -f
    else:
        dict_func['bdqrtic'][1].append(f)
        return f

countBdqrtic1 = 0
def bdqrtic1(x):
    global countBdqrtic1
    countBdqrtic1+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-4):
        f=f+(x[i]**2+2*x[i+1]**2+3*x[i+2]**2+4*x[i+3]**2+5*x[-1]**2)**2+(-4*x[i]+4)**2
    dict_func['bdqrtic1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdqrtic1'][1].append(-f)
        return -f
    else:
        dict_func['bdqrtic1'][1].append(f)
        return f

countBdvalue = 0
def bdvalue(x):
    global countBdvalue
    countBdvalue+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    h=1/(n+1)
    for i in range(n):
        if 0<i&i<n-1:
            f=f+(2*x[i]-x[i-1]-x[i+1]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**3)**2
        else:
            f=f+(2*x[i]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**3)**2
    dict_func['bdvalue'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdvalue'][1].append(-f)
        return -f
    else:
        dict_func['bdvalue'][1].append(f)
        return f       

countBdvalue1 = 0
def bdvalue1(x):
    global countBdvalue1
    countBdvalue1+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    h=1/(n+1)
    for i in range(n):
        if 0<i&i<n-1:
            f=f+(2*x[i]-x[i-1]-x[i+1]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**1)**2
        else:
            f=f+(2*x[i]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**3)**2
    dict_func['bdvalue1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdvalue1'][1].append(-f)
        return -f
    else:
        dict_func['bdvalue1'][1].append(f)
        return f

countBdvalue2 = 0
def bdvalue2(x):
    global countBdvalue2
    countBdvalue2+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    h=1/(n+1)
    for i in range(n):
        if 0<i&i<n-1:
            f=f+(2*x[i]-x[i-1]-x[i+1]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**2)**2
        else:
            f=f+(2*x[i]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**3)**2
    dict_func['bdvalue2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdvalue2'][1].append(-f)
        return -f
    else:
        dict_func['bdvalue2'][1].append(f)
        return f

countBdvalue3 = 0
def bdvalue3(x):
    global countBdvalue3
    countBdvalue3+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=1
    h=1/(n+1)
    for i in range(n):
        if 0<i&i<n-1:
            f=f+(2*x[i]-x[i-1]-x[i+1]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**2)**2
        else:
            f=f+(2*x[i]+0.5*h*h*(x[i]+(i+1)/(n+1)+1)**3)**2
    dict_func['bdvalue3'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdvalue3'][1].append(-f)
        return -f
    else:
        dict_func['bdvalue3'][1].append(f)
        return f

countChopwells = 0
def chpowells(x):
    global countChopwells
    countChopwells+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for j in range(int((n-2)/2)):
        i=2*(j+1)
        f=f+(x[i-2]+10*x[i-1])**2+5*(x[i]-x[i+1])**2+(x[i-1]-2*x[i])**4+10*(x[i-2]-x[i+1])**4
    dict_func['chpowells'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['chpowells'][1].append(-f)
        return -f
    else:
        dict_func['chpowells'][1].append(f)
        return f




def curly10(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    k=10
    n=len(x)
    f=0
    for i in range(n):
        tmp=0
        for j in range(n):
            if i<=j&(j+1)<=min(i+1+k,n):
                tmp=tmp+x[j]
    f=f+tmp*(tmp*(tmp**2-20)-0.1)
    dict_func['curly10'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['curly10'][1].append(-f)
        return -f
    else:
        dict_func['curly10'][1].append(f)
        return f
        
def curly20(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    k=20
    n=len(x)
    f=0
    for i in range(n):
        tmp=0
        for j in range(n):
            if i<=j&(j+1)<=min(i+1+k,n):
                tmp=tmp+x[j]
    f=f+tmp*(tmp*(tmp**2-20)-0.1)
    dict_func['curly20'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['curly20'][1].append(-f)
        return -f
    else:
        dict_func['curly20'][1].append(f)
        return f

def curly30(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    k=30
    n=len(x)
    f=0
    for i in range(n):
        tmp=0
        for j in range(n):
            if i<=j&(j+1)<=min(i+1+k,n):
                tmp=tmp+x[j]
    f=f+tmp*(tmp*(tmp**2-20)-0.1)
    dict_func['curly30'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['curly30'][1].append(-f)
        return -f
    else:
        dict_func['curly30'][1].append(f)
        return f        
    
countDixmaane =0 
def dixmaane(x):
    global countDixmaane
    countDixmaane+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0
    gamm=0.125
    delta=0.125
    p1=1
    p2=0
    p3=0
    p4=1
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaane'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaane'][1].append(-f)
        return -f
    else:
        dict_func['dixmaane'][1].append(f)
        return f
    
def dixmaanf(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.0625
    gamm=0.0625
    delta=0.0625
    p1=1
    p2=0
    p3=0
    p4=1
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaanf'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaanf'][1].append(-f)
        return -f
    else:
        dict_func['dixmaanf'][1].append(f)
        return f    
    
def dixmaang(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.125
    gamm=0.125
    delta=0.125
    p1=1
    p2=0
    p3=0
    p4=1
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaang'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaang'][1].append(-f)
        return -f
    else:
        dict_func['dixmaang'][1].append(f)
        return f
    
def dixmaanh(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.26
    gamm=0.26
    delta=0.26
    p1=1
    p2=0
    p3=0
    p4=1
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaanh'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaanh'][1].append(-f)
        return -f
    else:
        dict_func['dixmaanh'][1].append(f)
        return f  
        
def dixmaani(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0
    gamm=0.125
    delta=0.125
    p1=2
    p2=0
    p3=0
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaani'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaani'][1].append(-f)
        return -f
    else:
        dict_func['dixmaani'][1].append(f)
        return f
    
def dixmaanj(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.0625
    gamm=0.0625
    delta=0.0625
    p1=2
    p2=0
    p3=0
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaanj'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaanj'][1].append(-f)
        return -f
    else:
        dict_func['dixmaanj'][1].append(f)
        return f   
    
def dixmaank(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.125
    gamm=0.125
    delta=0.125
    p1=2
    p2=0
    p3=0
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaank'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaank'][1].append(-f)
        return -f
    else:
        dict_func['dixmaank'][1].append(f)
        return f
    
def dixmaanl(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.26
    gamm=0.26
    delta=0.26
    p1=2
    p2=0
    p3=0
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaanl'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaanl'][1].append(-f)
        return -f
    else:
        dict_func['dixmaanl'][1].append(f)
        return f   
        
def dixmaanm(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0
    gamm=0.125
    delta=0.125
    p1=2
    p2=1
    p3=1
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaanm'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaanm'][1].append(-f)
        return -f
    else:
        dict_func['dixmaanm'][1].append(f)
        return f
    
def dixmaann(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.0625
    gamm=0.0625
    delta=0.0625
    p1=2
    p2=1
    p3=1
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaann'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaann'][1].append(-f)
        return -f
    else:
        dict_func['dixmaann'][1].append(f)
        return f
    
def dixmaano(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.125
    gamm=0.125
    delta=0.125
    p1=2
    p2=1
    p3=1
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaano'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaano'][1].append(-f)
        return -f
    else:
        dict_func['dixmaano'][1].append(f)
        return f
    
def dixmaanp(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=n/3
    alpha=1
    beta=0.26
    gamm=0.26
    delta=0.26
    p1=2
    p2=1
    p3=1
    p4=2
    f1=0
    for i in range(n):
        f1=f1+((i+1)/n)**p1*x[i]**2
    f2=0
    for i in range(n-1):
        f2=f2+((i+1)/n)**p2*x[i]**2*(x[i+1]+x[i+1]**2)**2
    f3=0
    for i in range(2*int(m)):
        f3=f3+((i+1)/n)**p3*x[i]**2*x[i+int(m)]**4
    f4=0
    for i in range(int(m)):
        f4=f4+((i+1)/n)**p4*x[i]*x[i+int(m)]
    f=1
    f=f+alpha*f1+beta*f2+gamm*f3+delta*f4
    dict_func['dixmaanp'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dixmaanp'][1].append(-f)
        return -f
    else:
        dict_func['dixmaanp'][1].append(f)
        return f   
        
def dqrtic(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n):
        f=f+(x[i]-(i+1))**4
    dict_func['dqrtic'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['dqrtic'][1].append(-f)
        return -f
    else:
        dict_func['dqrtic'][1].append(f)
        return f

countEdensch =0 
def edensch(x):
    global countEdensch
    countEdensch +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=16
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-2*x[i+1])**2+(x[i+1]+1)**2
    dict_func['edensch'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch'][1].append(-f)
        return -f
    else:
        dict_func['edensch'][1].append(f)
        return f

countEdensch1 =0
def edensch1(x):
    global countEdensch1
    countEdensch1 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=15
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-2*x[i+1])**2+(x[i+1]+2)**2
    dict_func['edensch1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch1'][1].append(-f)
        return -f
    else:
        dict_func['edensch1'][1].append(f)
        return f

countEdensch2 =0
def edensch2(x):
    global countEdensch2
    countEdensch2 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=14
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-x[i+1])**2+(x[i+1]+1)**2
    dict_func['edensch2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch2'][1].append(-f)
        return -f
    else:
        dict_func['edensch2'][1].append(f)
        return f



countEdensch4 =0
def edensch4(x):
    global countEdensch4
    countEdensch4 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=16
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-x[i+1])**2+(x[i+1]+1)**2
    dict_func['edensch4'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch4'][1].append(-f)
        return -f
    else:
        dict_func['edensch4'][1].append(f)
        return f

countEdensch5 =0
def edensch5(x):
    global countEdensch5
    countEdensch5 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=14
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-1/2*x[i+1])**2+(x[i+1]+0.5)**2
    dict_func['edensch5'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch5'][1].append(-f)
        return -f
    else:
        dict_func['edensch5'][1].append(f)
        return f

countEdensch6 =0
def edensch6(x):
    global countEdensch6
    countEdensch6 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=16
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-3*x[i+1])**2+(x[i+1]+1)**2
    dict_func['edensch6'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch6'][1].append(-f)
        return -f
    else:
        dict_func['edensch6'][1].append(f)
        return f


countEg1 = 0
def eg1(x):
    global countEg1
    countEg1+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-1):
        f=f+math.sin(x[0]+x[i]**2-1)
    f=f+2*math.sin(x[n-1]**2)
    dict_func['eg1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['eg1'][1].append(-f)
        return -f
    else:
        dict_func['eg1'][1].append(f)
        return f

countEg2 = 0
def eg2(x):
    global countEg2
    countEg2+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-1):
        f=f+math.sin(x[0]+x[i]**2-1)
    f=f+math.sin(x[n-1]**2)
    dict_func['eg2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['eg2'][1].append(-f)
        return -f
    else:
        dict_func['eg2'][1].append(f)
        return f

countEg3 = 0
def eg3(x):
    global countEg3
    countEg3+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-1):
        f=f+0.5*math.sin(x[0]+x[i]**2-1)
    f=f+math.sin(x[n-1]**2)
    dict_func['eg3'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['eg3'][1].append(-f)
        return -f
    else:
        dict_func['eg3'][1].append(f)
        return f


def engval1(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-1):
        f=f+(x[i]**2+x[i+1]**2-4*x[i])+3
    dict_func['engval1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['engval1'][1].append(-f)
        return -f
    else:
        dict_func['engval1'][1].append(f)
        return f
    

def errinros(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-1):
        alpha=16*(1.5+math.sin((i+1)))**2
        f=f+(x[i]-alpha*x[i+1]**2)**2+(x[i]-1)**2
    dict_func['errinros'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['errinros'][1].append(-f)
        return -f
    else:
        dict_func['errinros'][1].append(f)
        return f
    
countExttet = 0
def exttet(x):
    global countExttet
    countExttet +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for j in range(int(n/2)):
        i=2*(j+1)
        f=f+math.exp(x[i-2]+3*x[i-1]-0.1)+math.exp(x[i-2]-3*x[i-1]-0.1)+math.exp(-x[i-2]+10)
    dict_func['exttet'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['exttet'][1].append(-f)
        return -f
    else:
        dict_func['exttet'][1].append(f)
        return f

def extrosnb(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=(x[0]-1)**2
    for i in range(n-1):
        f=f+100*(x[i+1]-x[i]**2)**2
    dict_func['extrosnb'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['extrosnb'][1].append(-f)
        return -f
    else:
        dict_func['extrosnb'][1].append(f)
        return f



countFletchcr = 0
def fletchcr(x):
    global countFletchcr
    countFletchcr +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-1):
        f=f+(x[i+1]-x[i]+1-x[i]**2)**2
    f=100*f
    dict_func['fletchcr'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['fletchcr'][1].append(-f)
        return -f
    else:
        dict_func['fletchcr'][1].append(f)
        return f


def freuroth(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    tmp1=0
    tmp2=0
    for i in range(n-1):
        tmp1=tmp1+((5-x[i+1])*x[i+1]**2+x[i]-2*x[i+1]-13)**2
        tmp2=tmp2+((1+x[i+1])*x[i+1]**2+x[i]-14*x[i+1]*x[i+1]-29)**2
    f=tmp1+tmp2
    dict_func['freuroth'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['freuroth'][1].append(-f)
        return -f
    else:
        dict_func['freuroth'][1].append(f)
        return f


def genhumps(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    zeta=2
    f=0
    for i in range(n-1):
        f=f+math.sin(zeta*x[i])**2*math.sin(zeta*x[i+1])**2+0.05*(x[i]**2+x[i+1]**2)
    dict_func['genhumps'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['genhumps'][1].append(-f)
        return -f
    else:
        dict_func['genhumps'][1].append(f)
        return f

def genrose(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=1
    for i in range(n-1):
        f=f+100*(x[i+1]-x[i]**2)**2+(x[i+1]-1)**2
    dict_func['genrose'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['genrose'][1].append(-f)
        return -f
    else:
        dict_func['genrose'][1].append(f)
        return f



def lilifun3(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        f=f+math.exp(x[i+1]-x[i])**2+(x[i+1]-x[i])**2+2*x[i+1]**4+4*x[i]**4
    dict_func['lilifun3'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['lilifun3'][1].append(-f)
        return -f
    else:
        dict_func['lilifun3'][1].append(f)
        return f


def morebv(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    h=1/(n+1)
    for i in range(n):
        if 1<=i & i<=n-2:
            f=f+(2*x[i]-x[i-1]-x[i+1]+0.5*h*h*(x[i]+(i+1)*h+1)**3)**2
        else:
            f=f+(2*x[i]+0.5*h*h*(x[i]+(i+1)*h+1)**3)**2
    dict_func['morebv'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['morebv'][1].append(-f)
        return -f
    else:
        dict_func['morebv'][1].append(f)
        return f

def morebvl(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    h=1/(n+1)
    for i in range(n):
        if 1<=i & i<=n-2:
            f=f+(2*x[i]-x[i-1]-x[i+1]+0.5*h*h*(x[i]+(i+1)*h+1)**3)**2
        else:
            f=f+(2*x[i]+0.5*h*h*(x[i]+(i+1)*h+1)**3)**2
    dict_func['morebvl'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['morebvl'][1].append(-f)
        return -f
    else:
        dict_func['morebvl'][1].append(f)
        return f
    

def ncb20b(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    if n>=20:
        tmp1=0
        for i in range(n-19):
            tmp=0
            for j in range(20):
                tmp=tmp+x[i+j]/(1+x[i+j]**2)
            tmp1=tmp1-10/(i+1)*tmp**2
            tmp=0
            for j in range(20):
                tmp=tmp+x[i+j]
            tmp1=tmp1-0.2*tmp
        tmp2=0
        for i in range(n):
            tmp2=tmp2+(100*x[i]**4+2)
        f=tmp1+tmp2
    dict_func['ncb20b'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['ncb20b'][1].append(-f)
        return -f
    else:
        dict_func['ncb20b'][1].append(f)
        return f
    


def nondia(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=(x[0]-1)**2
    for i in range(n-1):
        f=f+(100*x[0]-x[i]**2)**2
    dict_func['nondia'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['nondia'][1].append(-f)
        return -f
    else:
        dict_func['nondia'][1].append(f)
        return f

def nondquar(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=(x[0]-x[1])**2+(x[n-2]-x[n-1])**2
    for i in range(n-2):
        f=f+(x[i]+x[i+1]+x[n-1])**4
    dict_func['nondquar'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['nondquar'][1].append(-f)
        return -f
    else:
        dict_func['nondquar'][1].append(f)
        return f



def penalty3(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    r=0
    s=0
    pd=0
    for i in range(n):
        pd=pd+(x[i]**2-n)
    alpha=1
    for i in range(n-2):
        r=r+(x[i]+2*x[i+1]+10*x[i+2]-1)**2
        s=s+(2*x[i]+x[i+1]-3)**2
    for i in range(int(n/2)):
        f=f+(x[i]-1)**2
    f=f+pd**2+alpha*(1+r*math.exp(x[n-1])+s*math.exp(x[n-2])+r*s)
    dict_func['penalty3'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty3'][1].append(-f)
        return -f
    else:
        dict_func['penalty3'][1].append(f)
        return f 

def penalty4(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    r=0
    s=0
    pd=0
    for i in range(n):
        pd=pd+(x[i]**2-n)
    alpha=0.1
    for i in range(n-2):
        r=r+(x[i]+2*x[i+1]+10*x[i+2]-1)**2
        s=s+(2*x[i]+x[i+1]-3)**2
    for i in range(int(n/2)):
        f=f+(x[i]-1)**2
    f=f+pd**2+alpha*(1+r*math.exp(x[n-1])+s*math.exp(x[n-2])+r*s)
    dict_func['penalty4'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty4'][1].append(-f)
        return -f
    else:
        dict_func['penalty4'][1].append(f)
        return f


def penalty7(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    r=0
    s=0
    pd=0
    for i in range(n):
        pd=pd+(x[i]**2-n)
    alpha=10
    for i in range(n-2):
        r=r+(x[i]+2*x[i+1]+10*x[i+2]-1)**2
        s=s+(2*x[i]+x[i+1]-3)**2
    for i in range(int(n/2)):
        f=f+(x[i]-1)**2
    f=f+pd**2+alpha*(1+r*math.exp(x[n-1])+s*math.exp(x[n-2])+r*s)
    dict_func['penalty7'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty7'][1].append(-f)
        return -f
    else:
        dict_func['penalty7'][1].append(f)
        return f

def powellsg(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(int(n/4)):
        j=4*i+1
        f=f+(x[j]+10*x[j+1])**2+5*(x[j+2]-x[j+3])**2+(x[j+1]-2*x[j+2])**4+10*(x[j]-x[j+3])**4
    dict_func['powellsg'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['powellsg'][1].append(-f)
        return -f
    else:
        dict_func['powellsg'][1].append(f)
        return f

def power(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        f=f+((i+1)*x[i])**2
    dict_func['power'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['power'][1].append(-f)
        return -f
    else:
        dict_func['power'][1].append(f)
        return f

def sbrybnd(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    ml=5
    mu=1
    scaling=12
    f=0
    n=len(x)
    if n>=2:
        ytmp=np.zeros((n,1))
        for i in range(n):
            ytmp[i]=math.exp(scaling*(i/(n-1)))*x[i]
        for i in range(n):
            tmp=0
            for j in range(n):
                if max(1,i+1-ml)<=j+1&j+1<=min(n,i+1+mu):
                    if j!=i:
                        tmp=tmp+ytmp[j]*(1+ytmp[j])
            f=f+(ytmp[i]*(2+5*ytmp[i]*ytmp[i])+1-tmp)**2
    dict_func['sbrybnd'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['sbrybnd'][1].append(-f)
        return -f
    else:
        dict_func['sbrybnd'][1].append(f)
        return f

def sbrybndl(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    ml=5
    mu=1
    scaling=6
    f=0
    n=len(x)
    if n>=2:
        ytmp=np.zeros((n,1))
        for i in range(n):
            ytmp[i]=math.exp(scaling*(i/(n-1)))*x[i]
        for i in range(n):
            tmp=0
            for j in range(n):
                if max(1,i+1-ml)<=j+1&j+1<=min(n,i+1+mu):
                    if j!=i:
                        tmp=tmp+ytmp[j]*(1+ytmp[j])
            f=f+(ytmp[i]*(2+5*ytmp[i]*ytmp[i])+1-tmp)**2
    dict_func['sbrybndl'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['sbrybndl'][1].append(-f)
        return -f
    else:
        dict_func['sbrybndl'][1].append(f)
        return f
             

def scosine(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    scaling=12
    f=0
    if n>=2:
        ytmp=np.zeros((n,1))
        for i in range(n):
            ytmp[i]=math.exp(scaling*(i/(n-1)))*x[i]
        for i in range(n-1):
            f=f+math.cos(ytmp[i]**2-0.5*ytmp[i+1])
    dict_func['scosine'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['scosine'][1].append(-f)
        return -f
    else:
        dict_func['scosine'][1].append(f)
        return f

def scosinel(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    scaling=6
    f=0
    if n>=2:
        ytmp=np.zeros((n,1))
        for i in range(n):
            ytmp[i]=math.exp(scaling*(i/(n-1)))*x[i]
        for i in range(n-1):
            f=f+math.cos(ytmp[i]**2-0.5*ytmp[i+1])
    dict_func['scosinel'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['scosinel'][1].append(-f)
        return -f
    else:
        dict_func['scosinel'][1].append(f)
        return f 
    
def serose(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    if n>=6:
        f=(4*(x[0]-x[1]**2)+x[1]-x[2]**2+x[2]-x[3]**2)**2
        f=f+(8*x[1]*(x[1]**2-x[0])-2*(1-x[1])+4*(x[1]-x[2]**2)+x[2]-x[3]**2+x[3]-x[3]-x[4]**2)**2
        f=f+(8*x[2]*(x[2]**2-x[1])-2*(1-x[2])+4*(x[2]-x[3]**2)+x[1]**2-x[0]+x[3]-x[4]**2+x[4]-x[5]**6)**2
        for i in range(n):
            if 3<=i&i<=n-4:
                f=f+(8*x[i]*(x[i]**2-x[i-1])-2*(1-x[i])+4*(x[i]-x[i+1]**2)+x[i-1]**2-x[i-2]+x[i+1]-x[i+2]**2+x[i-2]**2-x[i-3]+x[i+2]-x[i+3]**2)**2
        f=f+(8*x[n-3]*(x[n-3]**2-x[n-4])-2*(1-x[n-3])+4*(x[n-3]-x[n-2]**2)-x[n-5]+x[n-2]-x[n-1]**2+x[n-5]**2-x[n-6])**2
        f=f+(8*x[n-2]*(x[n-2]-x[n-3])-2*(1-x[n-2])+4*(x[n-2]-x[n-1]**2)-x[n-4]+x[n-2]-x[n-2]**2+x[n-5])**2        
        f=f+(8*x[n-1]*(x[n-1]**2-x[n-2])-2*(1-x[n-1])+x[n-2]**2-x[n-3]+x[n-3]**2-x[n-4])**2
    dict_func['serose'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['serose'][1].append(-f)
        return -f
    else:
        dict_func['serose'][1].append(f)
        return f

def sinquad(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=(x[0]-1)**4
    for i in range(n-2):
        f=f+(math.sin(x[i+1]-x[n-1])-x[0]**2+x[i+1]**2)**2
    f=f+(x[n-1]**2-x[0]**2)**2
    dict_func['sinquad'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['sinquad'][1].append(-f)
        return -f
    else:
        dict_func['sinquad'][1].append(f)
        return f

def sphrpts(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    if n%2==0:
        info=2
    else:
        for i in range(int(n/2)-1):
            for j in range(i+1):
                f=f+1/((math.cos(x[2*(i+2)-2])*math.cos(x[2*(i+2)-1])-math.cos(x[2*(j+1)-2])*math.cos(x[2*(j+1)-1]))**2+(math.sin(x[2*(i+2)-2])*math.cos(x[2*(i+2)-1])-math.sin(x[2*(j+1)-2])*math.cos(x[2*(j+1)-1]))**2+(math.sin(x[2*(i+2)-1])-math.sin(x[2*(j+1)-1]))**2)
    dict_func['sphrpts'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['sphrpts'][1].append(-f)
        return -f
    else:
        dict_func['sphrpts'][1].append(f)
        return f

def sparsine(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        j1=2*(i+1)%n+1
        j2=3*(i+1)%n+1
        j3=5*(i+1)%n+1
        j4=7*(i+1)%n+1
        j5=11*(i+1)%n+1
        f=f+(i+1)*(math.sin(x[i])+math.sin(x[j1-1])+math.sin(x[j2-1])+math.sin(x[j3-1])+math.sin(x[j4-1])+math.sin(x[j5-1]))**2
    f=0.5*f
    dict_func['sparsine'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['sparsine'][1].append(-f)
        return -f
    else:
        dict_func['sparsine'][1].append(f)
        return f

def sparsqur(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        j1=2*(i+1)%n+1
        j2=3*(i+1)%n+1
        j3=5*(i+1)%n+1
        j4=7*(i+1)%n+1
        j5=11*(i+1)%n+1
        f=f+(i+1)*(x[i]**2+x[j1-1]**2+x[j2-1]**2+x[j3-1]**2+x[j4-1]**2+x[j5-1]**2)**2
    f=0.125*f
    dict_func['sparsqur'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['sparsqur'][1].append(-f)
        return -f
    else:
        dict_func['sparsqur'][1].append(f)
        return f

def spmsrtls(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    par=np.zeros((n,1))
    for i in range(n):
        par[i]=math.sin((i+1)**2)
    m=(n+2)/3
    f=0
    for i in range(int(m)):
        f1=0
        f2=0
        f3=0
        f4=0
        f5=0
        j=3*(i)+1
        if (i+1)>2:
            f1=(x[j-5]*x[j-2]-par[j-2]*par[j-5])**2
        f3=(x[j-1]**2-par[j-1]**2)**2
        if (i+1)>1:
            f2=(x[j-4]*x[j-2]+x[j-2]*x[j-1]-par[j-4]*par[j-2]-par[j-2]*par[j-1])**2
            f3=f3+(x[j-3]*x[j-2]-par[j-3]*par[j-2])**2
        if (i+1)<int(m):
            f3=f3+(x[j+1]*x[j]-par[j+1]*par[j])**2
            f4=(x[j+2]*x[j]+x[j]*x[j-1]-par[j+2]*par[j]-par[j]*par[j-1])**2
        if (i+1)<(m-1):
            f5=(x[j+3]*x[j]-par[j]*par[j+3])**2
    f=f1+f2+f3+f4+f5
    dict_func['spmsrtls'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['spmsrtls'][1].append(-f)
        return -f
    else:
        dict_func['spmsrtls'][1].append(f)
        return f

def srosenbr(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(int(n/2)):
        f=f+100*(x[2*(i+1)-1]-x[2*(i+1)-2]**2)**2+(x[2*(i+1)-2]-1)**2
    dict_func['srosenbr'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['srosenbr'][1].append(-f)
        return -f
    else:
        dict_func['srosenbr'][1].append(f)
        return f

def stmod(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    MST=np.zeros((n,n))
    for i in range(n):
        MST[0:i,i]=i+1
        MST[i,i]=MST[i,i]+1
    x=np.matmul(MST, x)
    for i in range(n):
        f=f+x[i]**4-16*x[i]**2+35*x[i]
    f=f+n*171.19854821721323
    dict_func['stmod'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['stmod'][1].append(-f)
        return -f
    else:
        dict_func['stmod'][1].append(f)
        return f

def tointgss(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-2):
        f=f+(10/(n+2)+x[i+2]**2)*(2-math.exp(-(x[i]-x[i+1])**2/(0.1+x[i+2]**2)))
    dict_func['tointgss'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['tointgss'][1].append(-f)
        return -f
    else:
        dict_func['tointgss'][1].append(f)
        return f

def tointtrig(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        betai=1+0.1*(i+2)
        for j in range(i+1):
            alpha=5*(1+(i+2)%5+(j+1)%5)
            betaj=1+0.1*(j+1)
            c=(i+2+j+1)*0.1
            f=f+alpha*math.sin(betai*x[i+1]+betaj*x[j]+c)
    dict_func['tointtrig'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['tointtrig'][1].append(-f)
        return -f
    else:
        dict_func['tointtrig'][1].append(f)
        return f
            
def tquartic(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=(x[0]-1)**2
    n=len(x)
    for i in range(n-1):
        f=f+(x[0]**2-x[i+1]**2)**2
    dict_func['tquartic'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['tquartic'][1].append(-f)
        return -f
    else:
        dict_func['tquartic'][1].append(f)
        return f

def trigsabs(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    MaS=np.zeros((2*n,n))
    MaC=np.zeros((2*n,n))
    sinx=np.zeros((n,1))
    cosx=np.zeros((n,1))
    so=np.zeros((n,1))
    co=np.zeros((n,1))
    for i in range(2*n):
        for j in range(n):
            MaS[i,j]=100*math.sin(((i+1)*(j+1)*n*163)**(0.25))
            MaC[i,j]=100*math.cos(((i+1)+(j+1)+n+42)/4)
    for j in range(n):
        sinx[j]=math.sin(x[j])
        cosx[j]=math.cos(x[j])
        so[j]=math.sin(math.pi*math.cos((n+(j+1)+163)/3))
        co[j]=math.cos(math.pi*math.cos((n+(j+1)+163)/3))
    d=np.matmul(MaS, sinx-so)+np.matmul(MaC, cosx-co)
    f=sum(abs(d))
    dict_func['trigsabs'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['trigsabs'][1].append(-f)
        return -f
    else:
        dict_func['trigsabs'][1].append(f)
        return f

def trigssqs(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    MaS=np.zeros((2*n,n))
    MaC=np.zeros((2*n,n))
    sinx=np.zeros((n,1))
    cosx=np.zeros((n,1))
    so=np.zeros((n,1))
    co=np.zeros((n,1))
    for i in range(2*n):
        for j in range(n):
            MaS[i,j]=100*math.sin(((i+1)*(j+1)*n*163)**(0.25))
            MaC[i,j]=100*math.cos(((i+1)+(j+1)+n+42)/4)
    for j in range(n):
        theta=(1+math.sin(n*(j+1)*42)**(1/3))/2
        theta=theta.real
        theta=10**(-theta)
        sinx[j]=math.sin(theta*x[j])
        cosx[j]=math.cos(theta*x[j])
        so[j]=math.sin(math.pi*math.cos((n+(j+1)+163)/3))
        co[j]=math.cos(math.pi*math.cos((n+(j+1)+163)/3))
    d=np.matmul(MaS, sinx-so)+np.matmul(MaC, cosx-co)
    f=sum(np.power(d, 2))
    dict_func['trigssqs'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['trigssqs'][1].append(-f)
        return -f
    else:
        dict_func['trigssqs'][1].append(f)
        return f
    
def trirose1(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    if n>=2:
        f=8*(x[0]-x[1]**2)**2
        for i in range(n-2):
            f=f+(8*x[i+1]*(x[i+1]**2-x[i])-2*(1-x[i+1])+8*(x[i+1]-x[i+2]**2))**2
    f=f+(8*x[n-1]*(x[n-1]**2-x[n-2])-2*(1-x[n-1]))**2
    dict_func['trirose1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['trirose1'][1].append(-f)
        return -f
    else:
        dict_func['trirose1'][1].append(f)
        return f

def trirose2(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    if n>=2:
        f=16*(x[0]-x[1]**2)**2
        for i in range(n-2):
            f=f+(8*x[i+1]*(x[i+1]**2-x[i])-2*(1-x[i+1])+8*(x[i+1]-x[i+2]**2))**2
    f=f+(8*x[n-1]*(x[n-1]**2-x[n-2])-2*(1-x[n-1]))**2
    dict_func['trirose2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['trirose2'][1].append(-f)
        return -f
    else:
        dict_func['trirose2'][1].append(f)
        return f   


def woods(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(int(n/4)):
        j=4*(i+1)-1
        f=f+100*(x[j-3]-x[j-4]**2)**2+(1-x[j-4])**2+90*(x[j-1]-x[j-2]**2)**2+(1-x[j-2])**2+10*(x[j-3]+x[j-1]-2)**2+0.1*(x[j-3]-x[j-1])**2
    dict_func['woods'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['woods'][1].append(-f)
        return -f
    else:
        dict_func['woods'][1].append(f)
        return f

dict_func = {}
fun_name = dir(obj_fun)
for func_name in fun_name:
    func = eval("obj_fun." + func_name)
    if isfunction(func):
        dict_func[func_name] = [[], []]



'''
def vardim(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        f=f+(i+1)*(x[i]-1)
    f=f*f
    f=f+f*f
    for i in range(n):
        f=f+(x[i]+1)*(x[i]+1)
    dict_func['vardim'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['vardim'][1].append(-f)
        return -f
    else:
        dict_func['vardim'][1].append(f)
        return f

countArglina4 =0 
def arglina4(x):
    global countArglina4
    countArglina4 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=int(2*n)
    tmp=0
    for i in range(n):
        tmp=tmp+x[i]
    f=0
    for i in range(n):
        f=f+(x[i]-2/m*tmp-1)**4
    for i in range(n):
        f=f+(-2/m*tmp-1)**4
    dict_func['arglina4'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['arglina4'][1].append(-f)
        return -f
    else:
        dict_func['arglina4'][1].append(f)
        return f


countArglinc = 0
def arglinc(x):
    global countArglinc
    countArglinc+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
        # print("11111111111111111111111")
        # print(x)
    n=len(x)
    m=int(2*n)
    tmp=0
    for i in range(n-2):
        tmp=tmp+(i+1)*x[i+1]**2
    f=1
    for i in range(n-2):
        f=f+(i*tmp-1)**2
    f=f+1
    for i in range(m):
        f=f+((i+1)*tmp-1)**2
    dict_func['arglinc'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['arglinc'][1].append(-f)
        return -f
    else:
        dict_func['arglinc'][1].append(f)
        return f
    
countArwhead = 0
def arwhead(x):
    global countArwhead
    countArwhead+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    m=int(2*n)
    f=0
    for i in range(n-1):
        f=f+(x[i]*x[i]+x[n-1]*x[n-1])**2-4*x[i]+3
    dict_func['arwhead'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['arwhead'][1].append(-f)
        return -f
    else:
        dict_func['arwhead'][1].append(f)
        return f

def penalty5(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    r=0
    s=0
    pd=0
    for i in range(n):
        pd=pd+(x[i]**2-n)
    alpha=0.5
    for i in range(n-2):
        r=r+(x[i]+2*x[i+1]+10*x[i+2]-1)**2
        s=s+(2*x[i]+x[i+1]-3)**2
    for i in range(int(n/2)):
        f=f+(x[i]-1)**2
    f=f+pd**2+alpha*(1+r*math.exp(x[n-1])+s*math.exp(x[n-2])+r*s)
    dict_func['penalty5'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty5'][1].append(-f)
        return -f
    else:
        dict_func['penalty5'][1].append(f)
        return f
def penalty6(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    r=0
    s=0
    pd=0
    for i in range(n):
        pd=pd+(x[i]**2-n)
    alpha=5
    for i in range(n-2):
        r=r+(x[i]+2*x[i+1]+10*x[i+2]-1)**2
        s=s+(2*x[i]+x[i+1]-3)**2
    for i in range(int(n/2)):
        f=f+(x[i]-1)**2
    f=f+pd**2+alpha*(1+r*math.exp(x[n-1])+s*math.exp(x[n-2])+r*s)
    dict_func['penalty6'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty6'][1].append(-f)
        return -f
    else:
        dict_func['penalty6'][1].append(f)
        return f

countBdqrtic2 = 0
def bdqrtic2(x):
    global countBdqrtic2
    countBdqrtic2+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=1
    n=len(x)
    for i in range(n-4):
        f=f+(x[i]**2+2*x[i+1]**2+3*x[i+2]**2+4*x[i+3]**2+5*x[-1]**2)**2+(-4*x[i]+3)**2
    dict_func['bdqrtic2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdqrtic2'][1].append(-f)
        return -f
    else:
        dict_func['bdqrtic2'][1].append(f)
        return f

def penalty3p(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    r=0
    s=0
    pd=0
    for i in range(n):
        pd=pd+(x[i]**2-n)
    alpha=1.0e-2
    for i in range(n-2):
        r=r+(x[i]+2*x[i+1]+10*x[i+2]-1)**2
        s=s+(2*x[i]+x[i+1]-3)**2
    for i in range(int(n/2)):
        f=f+(x[i]-1)**2
    f=f+pd**2+alpha*(1+r*math.exp(x[n-1])+s*math.exp(x[n-2])+r*s)
    dict_func['penalty3p'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty3p'][1].append(-f)
        return -f
    else:
        dict_func['penalty3p'][1].append(f)
        return f
    

countBdqrticp =0 
def bdqrticp(x):
    global countBdqrticp
    countBdqrticp+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n-4):
        f=f+(x[i]**2+2*x[i+1]**2+3*x[i+2]**2+4*x[i+3]**2+5*x[-1]**2)**2+-4*x[i]-3
    dict_func['bdqrticp'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['bdqrticp'][1].append(-f)
        return -f
    else:
        dict_func['bdqrticp'][1].append(f)
        return f

countBrownal = 0
def brownal(x):
    global countBrownal
    countBrownal +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    tmp1=0
    tmp2=1
    for i in range(n):
        tmp1=tmp1+x[i]
        tmp2=tmp2*x[i]
        
    f=(tmp2-1)**2
    for i in range(n-1):
        f=f+(x[i]+tmp1-(n+1))**2
    dict_func['brownal'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['brownal'][1].append(-f)
        return -f
    else:
        dict_func['brownal'][1].append(f)
        return f

countBroydn3d = 0
def broydn3d(x):
    global countBroydn3d
    countBroydn3d+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        if 0<i&i<n-1:
            f=f+((3-2*x[i])*x[i]-x[i-1]-2*x[i+1]+1)**2
        else:
            f=f+((3-2*x[i])*x[i]+1)**2
    dict_func['broydn3d'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['broydn3d'][1].append(-f)
        return -f
    else:
        dict_func['broydn3d'][1].append(f)
        return f      

countBroydn7d = 0
def broydn7d(x):
    global countBroydn7d
    countBroydn7d +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        if 0<i&i<n-1:
            f=f+abs(x[i-1]-x[i]*(3-0.5*x[i+1])+2*x[i+1]-1)**(7/3)
        else:
            f=f+abs(-x[i]*(3)-1)**(7/3)
    for i in range(int(n/2)):
        f=f+abs(x[i]+x[i+int((n-1)/2)])**(7/3)
    dict_func['broydn7d'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['broydn7d'][1].append(-f)
        return -f
    else:
        dict_func['broydn7d'][1].append(f)
        return f

countBrybnd = 0
def brybnd(x):
    global countBrybnd
    countBrybnd += 1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    ml=5
    mu=1
    f=0
    for i in range(n):
        tmp=0
        for j in range(n):
            if max(1,(i+1)-ml)<=j&j<=min(n,(i+1)+mu):
                if j == i:
                    tmp=tmp+x[j-1]*(1+x[j-1])
        f=f+(x[i]*(2+5*x[i])+1-tmp)**2
    dict_func['brybnd'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['brybnd'][1].append(-f)
        return -f
    else:
        dict_func['brybnd'][1].append(f)
        return f

def chrosen(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        f=f+4*(x[i]-x[i+1]*x[i+1])*(x[i]-x[i+1]*x[i+1])+(1-x[i+1])*(1-x[i+1])
    dict_func['chrosen'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['chrosen'][1].append(-f)
        return -f
    else:
        dict_func['chrosen'][1].append(f)
        return f


def penalty1(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    dp1=0
    dp2=0
    for i in range(n):
        dp1=dp1+(x[i]-1)**2
        dp2=dp2+x[i]**2
    f=1.0e-5*dp1+(0.25-dp2)**2
    dict_func['penalty1'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty1'][1].append(-f)
        return -f
    else:
        dict_func['penalty1'][1].append(f)
        return f


countChainwoo = 0
def chainwoo(x):
    global countChainwoo
    countChainwoo+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=1
    for i in range(int(n/2-1)):
        j=2*(i+1)
        f=f+100*(x[j-1]-x[j-2]**2)**2+(1-x[j-2])**2+90*(x[j+1]-x[j]**2)**2+(1-x[j])**2+10*(x[j-1]+x[j+1]-2)**2+0.1*(x[j-1]-x[j+1])**2
    dict_func['chainwoo'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['chainwoo'][1].append(-f)
        return -f
    else:
        dict_func['chainwoo'][1].append(f)
        return f
        
        
def penalty2(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    tmp=0
    for i in range(n-1):
        f=f+(math.exp(x[i]*0.1)+math.exp(x[i+1]*0.1)-math.exp((i+1)*0.1)-math.exp((i+2)*0.1))**2+(math.exp(x[i+1]*0.1)-math.exp(-0.1))**2
    for i in range(n):
        tmp=tmp+(n-i)*x[i]*x[i]
    f=f+(1-tmp)*(1-tmp)+(x[0]-0.2)*(x[0]-0.2)
    dict_func['penalty2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['penalty2'][1].append(-f)
        return -f
    else:
        dict_func['penalty2'][1].append(f)
        return f

def genbrown(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        f=f+(x[i]-3)**2+(x[i]-x[i+1])**2+math.exp(20*(x[i]-x[i+1]))
    dict_func['genbrown'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['genbrown'][1].append(-f)
        return -f
    else:
        dict_func['genbrown'][1].append(f)
        return f


def integreq(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    h=1/(n+1)
    t=np.zeros((1,n))
    t=t[0]
    for i in range(n):
        t[i]=(i+1)/(n+1)
    f=0
    for i in range(n):
        tmp1=0
        for j in range(i+1):
            tmp1=tmp1+t[j]*(x[j]+t[j]+1)**3
        tmp2=0
        for j in range(n-i-1):
            tmp2=tmp2+(1-t[j+i+1])*(x[j+i+1]+t[j+i+1]+1)**3
        f=f+(x[i]+0.5*h*((1-t[i])*tmp1+t[i]*tmp2))**2
    dict_func['integreq'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['integreq'][1].append(-f)
        return -f
    else:
        dict_func['integreq'][1].append(f)
        return f

def liarwhd(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n):
        f=f+4*(x[i]**2-x[0])**2+(x[i]-1)**2
    dict_func['liarwhd'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['liarwhd'][1].append(-f)
        return -f
    else:
        dict_func['liarwhd'][1].append(f)
        return f


countEdensch3 =0
def edensch3(x):
    global countEdensch3
    countEdensch3 +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=16
    for i in range(n-1):
        f=f+(x[i]-2)**4+(x[i]*x[i+1]-2*x[i+1])**2+(x[i+1]+3)**2
    dict_func['edensch3'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['edensch3'][1].append(-f)
        return -f
    else:
        dict_func['edensch3'][1].append(f)
        return f


countCragglvy = 0
def cragglvy(x):
    global countCragglvy
    countCragglvy+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for j in range(int((n-2)/2)):
        i=2*(j+1)
        f=f+(math.exp(x[i-2])-x[i-1])**4+100*(x[i-1]-x[i])**6+(math.tan(x[i]-x[i-1])+x[i]-x[i+1])**4+x[i-2]**8+(x[i+1]-1)**2
    dict_func['cragglvy'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['cragglvy'][1].append(-f)
        return -f
    else:
        dict_func['cragglvy'][1].append(f)
        return f

def fletcbv2(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    h=1/(n+1)
    tmp1=x[0]**2
    for i in range(n-1):
        tmp1=tmp1+(x[i]-x[i+1])**2
    tmp1=tmp1+x[n-1]**2
    tmp2=0
    for i in range(n):
        tmp2=tmp2+2*x[i]+math.cos(x[i])
    f=0.5*tmp1-h**2*tmp2-x[n-1]
    dict_func['fletcbv2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['fletcbv2'][1].append(-f)
        return -f
    else:
        dict_func['fletcbv2'][1].append(f)
        return f

def fletcbv3(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    p=1.0e-8
    h=1/(n+1)
    kappa=1
    tmp1=x[0]**2
    for i in range(n-1):
        tmp1=tmp1+(x[i]-x[i+1])**2
    tmp1=tmp1+x[n-1]**2
    tmp2=0
    for i in range(n):
        tmp2=tmp2+100*math.sin(x[i]*0.01)*(1+2/h**2)+1/h**2*kappa*math.cos(x[i])
    f=0.5*p*tmp1-p*tmp2
    dict_func['fletcbv3'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['fletcbv3'][1].append(-f)
        return -f
    else:
        dict_func['fletcbv3'][1].append(f)
        return f


countCube = 0
def cube(x):
    global countCube
    countCube +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=(x[0]-1)**2
    for i in range(n-1):
        f=f+100*(x[i+1]-x[i]**3)**2
    dict_func['cube'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['cube'][1].append(-f)
        return -f
    else:
        dict_func['cube'][1].append(f)
        return f
    
countChpowellb = 0
def chpowellb(x):
    global countChpowellb
    countChpowellb+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        f=f+(10000+x[i]*x[i+1]-1)**2+(math.exp(-x[i])+math.exp(-x[i+1])-1)**2
    dict_func['chpowellb'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['chpowellb'][1].append(-f)
        return -f
    else:
        dict_func['chpowellb'][1].append(f)
        return f


countRastrigin_grad = 0
def rastrigin_grad(x):
    global countRastrigin_grad
    countRastrigin_grad +=1
    A = 0.1
    dict_func['rastrigin_grad'][0].append(x)
    dict_func['rastrigin_grad'][1].append(2*x + A*np.sin(2*np.pi*x))
    return 2*x + A*np.sin(2*np.pi*x)

countRosenbrock = 0
def rosenbrock(x0):
    global countRosenbrock
    countRosenbrock += 1
    M = 0.01
    x = x0.copy()
    if len(x.shape) == 1: x = x.reshape(-1,1)
    xshift = np.roll(x, -1, axis=0)
    xclip = x[0:-1,:]
    xshiftclip = xshift[0:-1,:]
    
    xdiff = M*(xshiftclip-xclip**2)**2 + (1-xclip)**2
    
    ###################################
    # global fff
    # fff=np.append(fff, np.sum(xdiff, axis=0) + 100)
    ###################################
    dict_func['rosenbrock'][0].append(x)
    dict_func['rosenbrock'][1].append(np.sum(xdiff, axis=0) + 100)
    return np.sum(xdiff, axis=0) + 100

countRosenbrock_grad = 0
def rosenbrock_grad(x):
    global countRosenbrock_grad
    countRosenbrock_grad +=1
    M = 0.01
    xdshift = np.roll(x,  1, axis=0)
    xushift = np.roll(x, -1, axis=0)
    grad_x = -4*M*(xushift-x**2)*x - 2*(1-x) + 2*M*(x-xdshift**2)

    grad_x[0,:] = -4*M*(xushift[0,:]-x[0,:]**2)*x[0,:] - 2*(1-x[0,:])
    grad_x[-1,:] = 2*M*(x[-1,:]-xdshift[-1,:]**2)
    dict_func['rosenbrock_grad'][0].append(x)
    dict_func['rosenbrock_grad'][1].append(grad_x)
    return grad_x

countChnrosnb =0
def chnrosnb(x):
    global countChnrosnb
    countChnrosnb +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        alpha=16*(1.5+math.sin(i+1))**2
        f=f+alpha*(x[i]-x[i+1]**2)**2+(x[i+1]-1)**2
    dict_func['chnrosnb'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['chnrosnb'][1].append(-f)
        return -f
    else:
        dict_func['chnrosnb'][1].append(f)
        return f

countCosine = 0
def cosine(x):
    global countCosine
    countCosine+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        f=f+math.cos(x[i]**2-0.5*x[i+1])
    dict_func['cosine'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['cosine'][1].append(-f)
        return -f
    else:
        dict_func['cosine'][1].append(f)
        return f

countFirose = 0 
def firose(x):
    global countFirose
    countFirose +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    if n>=4:
        f=(4*(x[0]-x[1]**2)+x[1]-x[2]**2)**2+(8*x[1]*(x[1]**2-x[0])-2*(1-x[1])+4*(x[1]-x[2]**2)+x[2]-x[3]**2)**2
    for i in range(n):
        if i<=n-3&i>=2:
            f=f+(8*x[i]*(x[i]**2-x[i-1])-2*(1-x[i])+4*(x[i]-x[i+1]**2)+x[i-1]**2-x[i-2]+x[i+1]-x[i+2]**2)**2
    f = f + (8*x[n-2]*(x[n-2]**2-x[n-3])-2*(1-x[n-2])+4*(x[n-2]-x[n-1]**2)+ x[n-3]**2-x[n-4])**2
    f = f + (8*x[n-1]*(x[n-1]**2-x[n-2])-2*(1-x[n-1])+x[n-2]**2-x[n-3])**2
    dict_func['firose'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['firose'][1].append(-f)
        return -f
    else:
        dict_func['firose'][1].append(f)
        return f




# def sphere(x):
#     xx=x
#     if str(type(x))=="<class 'zoopt.solution.Solution'>":
#         x = x.get_x()
#     if str(type(x))=="<class 'dict'>":
#         X=np.zeros((1,len(x)))
#         X=X[0]
#         for i in range(len(x)):
#             X[i]=x["x"+str(i+1)]
#         x=X
#     n=len(x)
#     f=0
#     alpha=1
#     omege=0
#     if str(type(xx))=="<class 'dict'>":
#         return -f
#     else:
#         return f
    
# def Ackley(x):
#     xx=x
#     if str(type(x))=="<class 'zoopt.solution.Solution'>":
#         x = x.get_x()
#     if str(type(x))=="<class 'dict'>":
#         X=np.zeros((1,len(x)))
#         X=X[0]
#         for i in range(len(x)):
#             X[i]=x["x"+str(i+1)]
#         x=X
#     n=len(x)
#     f=0
#     alpha=1
#     beta=1
#     gamma=1
#     delta=1
#     omega=0
#     A=20
#     angle=2 * math.pi
#     s=0
#     for i in range(n):
#         s=s+x[i]*x[i]
#     loss1=-A*math.exp(-0.2*math.sqrt(0.5*s))
#     p=0
#     for i in range(n):
#         p=p+math.cos(angle*x[i])
#     loss2=-math.exp(0.5*p)
#     loss3=math.exp(1)
#     loss4=A
#     f=alpha*
    
    
#     if str(type(xx))=="<class 'dict'>":
#         return -f
#     else:
#         return f
    
# def woods(x):
#     xx=x
#     if str(type(x))=="<class 'zoopt.solution.Solution'>":
#         x = x.get_x()
#     if str(type(x))=="<class 'dict'>":
#         X=np.zeros((1,len(x)))
#         X=X[0]
#         for i in range(len(x)):
#             X[i]=x["x"+str(i+1)]
#         x=X
#     n=len(x)
#     f=0
#     for i in range(int(n/4)):
#         j=4*(i+1)-1
#         f=f+100*(x[j-3]-x[j-4]**2)**2+(1-x[j-4])**2+90*(x[j-1]-x[j-2]**2)**2+(1-x[j-2])**2+10*(x[j-3]+x[j-1]-2)**2+0.1*(x[j-3]-x[j-1])**2
#     if str(type(xx))=="<class 'dict'>":
#         return -f
#     else:
#         return f
    
# def woods(x):
#     xx=x
#     if str(type(x))=="<class 'zoopt.solution.Solution'>":
#         x = x.get_x()
#     if str(type(x))=="<class 'dict'>":
#         X=np.zeros((1,len(x)))
#         X=X[0]
#         for i in range(len(x)):
#             X[i]=x["x"+str(i+1)]
#         x=X
#     n=len(x)
#     f=0
#     for i in range(int(n/4)):
#         j=4*(i+1)-1
#         f=f+100*(x[j-3]-x[j-4]**2)**2+(1-x[j-4])**2+90*(x[j-1]-x[j-2]**2)**2+(1-x[j-2])**2+10*(x[j-3]+x[j-1]-2)**2+0.1*(x[j-3]-x[j-1])**2
#     if str(type(xx))=="<class 'dict'>":
#         return -f
#     else:
#         return f

def indef(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    tmp1=0
    for i in range(n):
        tmp1=tmp1+100*math.sin(0.01*x[i])
    tmp2=0
    for i in range(n-2):
        tmp2=tmp2+math.cos(2*x[i+1]-x[n-1]-x[0])
    f=tmp1+0.5*tmp2
    dict_func['indef'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['indef'][1].append(-f)
        return -f
    else:
        dict_func['indef'][1].append(f)
        return f

def lilifun4(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-1):
        f=f+0.5*(x[i+1]-x[i])**2+math.sin(x[i+1]-x[i])+2*(2*x[i+1]+3*x[i]-15)**4
    dict_func['lilifun4'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['lilifun4'][1].append(-f)
        return -f
    else:
        dict_func['lilifun4'][1].append(f)
        return f

def noncvxu2(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n):
        j=(3*(i+1)-2)%n
        k=(7*(i+1)-3)%n
        tmp=x[i]+x[j]+x[k]
        f=f+tmp**2+4*math.cos(tmp)
    dict_func['noncvxu2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['noncvxu2'][1].append(-f)
        return -f
    else:
        dict_func['noncvxu2'][1].append(f)
        return f

def noncvxun(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    n=len(x)
    for i in range(n):
        j=(2*(i+1)-1)%n
        k=(3*(i+1)-1)%n
        tmp=x[i]+x[j]+x[k]
        f=f+tmp**2+4*math.cos(tmp)
    dict_func['noncvxun'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['noncvxun'][1].append(-f)
        return -f
    else:
        dict_func['noncvxun'][1].append(f)
        return f    

'''


'''
countExpsum = 0
def expsum(x):
    global countExpsum
    countExpsum +=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    f=0
    alpha=4
    beta=2*math.sqrt(alpha)
    n=len(x)
    for i in range(n):
        f=f+(i+1)**2*(math.exp((i+1)*sum(x[0:i]))+alpha*math.exp(-(i+1)*sum(x[0:i]))-beta)
    dict_func['expsum'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['expsum'][1].append(-f)
        return -f
    else:
        dict_func['expsum'][1].append(f)
        return f
    

countChebquad = 0
def chebquad(x):
    global countChebquad
    countChebquad+=1
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    ychebq=np.zeros((n+1,n))
    ychebq[0,:]=np.ones((1,n))
    print(x)
    print(np.ones((1,n)))
    print(type(x))
    ychebq[1,:]=2*x[:]-np.ones((1,n))
    for i in range(n-1):
        ychebq[i+2,:]=np.multiply(2*ychebq[1,:], ychebq[i+1,:])-ychebq[i,:]
    f=0
    for i in range(n+1):
        tmp=sum(ychebq[i,:])/n
        if (i+1)%2==1:
            tmp=tmp+1/((i+1)*(i+1)-2*(i+1))
        f=f+tmp*tmp
    dict_func['chebquad'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['chebquad'][1].append(-f)
        return -f
    else:
        dict_func['chebquad'][1].append(f)
        return f

def fminsrf2(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    k=math.floor(math.sqrt(n))
    ysrf=np.zeros((k,k))
    hk=math.floor(k/2)
    if k<=1:
        info=2
    for i in range(k):
        for j in range(k):
            ysrf[i,j]=x[i*k+j]
    for i in range(k-1):
        for j in range(k-1):
            f=f+math.sqrt(1+5*(k-1)**2*(((ysrf[i,j]-ysrf[i+1,j+1])**2+(ysrf[i+1,j]-ysrf[i,j+1])**2)))
    f=f/(k-1)**2+ysrf[hk-1,hk-1]**2/n
    dict_func['fminsrf2'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['fminsrf2'][1].append(-f)
        return -f
    else:
        dict_func['fminsrf2'][1].append(f)
        return f

def ncb20(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    if n>=20:
        tmp1=0
        for i in range(n-30):
            tmp=0
            for j in range(20):
                tmp=tmp+x[i+j]
            tmp1=tmp1-0.2*tmp
        tmp2=0
        for i in range(n-10):
            tmp2=tmp+x[i]**4+2
        tmp3=0
        for i in range(10):
            tmp3=tmp3+x[i]*x[i+10]*x[i+n-10]+2*x[i+n-10]**2
        f=2+tmp1+tmp2+1.0e-4*tmp3
    dict_func['ncb20'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['ncb20'][1].append(-f)
        return -f
    else:
        dict_func['ncb20'][1].append(f)
        return f
    
countQuadratic_grad = 0
def quadratic_grad(x):
    global countQuadratic_grad
    countQuadratic_grad +=1
    dict_func['quadratic_grad'][0].append(x)
    dict_func['quadratic_grad'][1].append(2*x)
    return 2*x
    
def schmvett(x):
    xx=x
    if str(type(x))=="<class 'zoopt.solution.Solution'>":
        x = x.get_x()
    if str(type(x))=="<class 'dict'>":
        X=np.zeros((1,len(x)))
        X=X[0]
        for i in range(len(x)):
            X[i]=x["x"+str(i+1)]
        x=X
    n=len(x)
    f=0
    for i in range(n-2):
        f=f-1/(1+(x[i]-x[i+1])**2)-math.sin(0.5*(math.pi*x[i+1]+x[i+2]))-math.exp(-((x[i]+x[i+2])/x[i+1]-2)**2)
    dict_func['schmvett'][0].append(x)
    if str(type(xx))=="<class 'dict'>":
        dict_func['schmvett'][1].append(-f)
        return -f
    else:
        dict_func['schmvett'][1].append(f)
        return f

    
    
'''