"""
Description:
This module runs six popular test problems for global optimization
that are defined and described in blackbox_opt/test_funcs/funcs_def.py.

The user is required to import a blackbox function, specify the
algorithm, a starting point and options.
            func: an imported blackbox function object
            x_0: starting point: numpy array with shape (n,1) --n is the
            dimension of x_0
            alg: selected algorithm: string
            options : a dictionary of options customized for each algorithm
For a full list of options available for DFO see the README file in
DFO_src directory.
For scipy algorithms, options for each alg are available by a call to
scipy.optimize.show_options. These options are available at
http://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.optimize.show_options.html
"""
import numpy as np
from alg1.bb_optimize import bb_optimize
from alg1.obj_fun import dict_func
import alg1.obj_fun
from inspect import isfunction
import torch
import pickle

class argsPara():
    def __init__(self):
        self.tau = 3000
        self.seed = 1
        self.cuda_use = False


def get_results(args, func, x_0, alg, options):
    """
    This function calls the main blackbox optimization
    code with the specified algorithm, options and starting point and
    prints the best point found along with its optimal value.
    input: func: an imported blackbox function object
            x_0: starting point: numpy array with shape (n,1)
            alg: selected algorithm: string
            options : a dictionary of options customized for each algorithm
    """
    res = bb_optimize(args, func, x_0, alg, options)
    '''
    print ("Printing result for function " + func.__name__ + ":")
    print ("best point: {}, with obj: {:.6f}".format(
        np.around(res.x.T, decimals=5), float(res.fun)))
    print ("-------------" + alg + " Finished ----------------------\n")
    '''

def arrayTolist(x_array, y_array, n):
    '''
        将数组类型数据转换为列表类型数据
        x_array, y_array: 输入数据和函数值
        n: 输入数据的维度
    '''
    length = len(y_array)
    y_list = []
    x_list = []
    for i in range(length):
        y_list.append(torch.tensor(y_array[i]))
        x_list.append(x_array[i].reshape(n).tolist())
    return torch.tensor(x_list), torch.tensor(y_list)


def save(dict_results, func_name, x_0, algindex):
    '''
    保存函数值
    '''
    dict_results[func_name] = [float('inf')]
    filename = "./results/dict_file" + str(algindex)
    f = open(filename, 'w')
    f.write(str(dict_results))
    f.close()
    return dict_results


def test_fun1(args):

    dict_results = {}
    all_func_names = dir(alg1.obj_fun)
    inf_name = []
    n = args.np  # 输入数据的维度

    # 定义算法和参数
    alg = "DFO"
    options = {"maxfev": args.itr, "init_delta": 10,
               "tol_delta": 1e-28, "tol_f": 1e-28, "tol_norm_g": 1e-8,
               "sample_gen": "auto", "verbosity": 0}
    print("函数是：", alg)

    func_name_unproper = ['_init', 'func', 'isfunction']
    for func_name in all_func_names:
        func = eval("alg1.obj_fun." + func_name)
        if isfunction(func) and func_name not in func_name_unproper:
            #print("函数是：", func)
            #print ("\n *********" + func.__name__ + " function ********")
            x_0 = np.zeros((n, 1))  # 模型初始值

            get_results(args, func, x_0, alg, options)
            input = dict_func[func_name][0]
            output = dict_func[func_name][1]

            input, output = arrayTolist(input, output, n)
            if torch.isinf(max(output)):
                inf_name.append(func_name)
                print(func_name)
                continue
            #print("results: 每一轮迭代的x为 {}, 每一轮迭代的y为 {}".format(input, output))

            #将非0数据存储在字典中
            dict_results[func_name] = output.tolist()

            #保存数据
            f = open("./results/dict_file1", 'w')
            f.write(str(dict_results))
            f.close()

    print(inf_name)
    return dict_results
