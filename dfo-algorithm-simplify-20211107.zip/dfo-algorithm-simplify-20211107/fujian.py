import torch
from alg1.run_test_func1 import test_fun1
from alg2.run_test_func2 import test_fun2
from alg3.run_test_func3 import test_fun3
from alg4.run_test_func4 import test_fun4
from alg5.run_test_func5 import test_fun5

import matplotlib.pyplot as plt
import math

class loadData():
    def loaddata(self, args):
        data = []
        dict_results1 = test_fun1(args)
        data.append(dict_results1)
        dict_results2 = test_fun2(args)
        data.append(dict_results2)
        dict_results3 = test_fun3(args)
        data.append(dict_results3)
        dict_results4 = test_fun4(args)
        data.append(dict_results4)
        dict_results5 = test_fun5(args)
        data.append(dict_results5)
        return data


def preProcess(data, args):
    func_list = []    # 函数名，维度为问题数目
    y_init = []   # 各个问题的初始值，维度为问题数目
    opt = []   # 存储多个算法处理各个问题的最优值，维度为问题数目
    minimum = []   # 两个算法对应的最小值
    min_index = []   # 两个算法对应的最小迭代次数
    y_labels = []     # 两个算法的最优函数值
    tap = []
    for i in range(args.algNum):
        minimum.append([])
        min_index.append([])
        y_labels.append({})
        tap.append([])
    opt = []

    for key in data[0].keys():
        optvalue = min(data[0][key])
        for j in range(args.algNum):
            labels = min(data[j][key])
            optvalue = min(labels, optvalue)
        if optvalue == data[0][key][0]:
            continue
        opt.append(optvalue)

        func_list.append(key)   # 有效函数名
        if data[0][key][0] != data[1][key][0]:    # 判断初始值是否一致
            print("初始数据不一致", key)
        y_init.append(data[0][key][0])   # 各个问题的初始值

        # 计算算法2的最优值和最优索引
        labels = data[1][key]
        min_num = min(labels)
        index = labels.index(min_num) + 1
        for i in range(args.algNum):
            if i == 0:
                y_labels[i][key] = data[i][key][0:args.itr]  # 分别存储我们的算法的函数值
            else:
                y_labels[i][key] = data[i][key][0:args.itr]   # 分别存储算法1和算法2的函数值
            min_num = min(y_labels[i][key])   # 计算最小函数值
            index = y_labels[i][key].index(min_num) + 1   # 最小函数值的索引+1 = 取最小函数值所需的迭代次数
            minimum[i].append(min_num)
            if min_num == float('inf'):      # 处理函数值中存在的inf数据，最小迭代次数为总迭代次数乘以100，tap设置为0
                print('inf', i, key, min_num)
                min_index[i].append(args.itr*100)
                tap[i].append(0)
            else:
                tap[i].append(1)
                min_index[i].append(index)
    return func_list, minimum, min_index, y_init, tap, opt

def optValue(minimum, args):
    '''
    统计各个函数的最优值，即各个函数的f(x*)
    '''
    opt = []
    for i in range(len(minimum[0])):
        min_num = minimum[0][i]
        for j in range(1, args.algNum):
            min_num = min(min_num, minimum[j][i])
        opt.append(min_num)
    return opt

def f_acc_N(args, minimum, opt, y_init, tap):
    length = len(opt)
    faccN = []
    for j in range(args.algNum):
        faccN.append([])
    for i in range(length):
        differ = opt[i] - y_init[i]
        for j in range(args.algNum):
            if tap[j][i] == 0:
                faccN[j].append(0)
            else:
                faccN[j].append( (minimum[j][i]-y_init[i]) / differ )
    return faccN

def Tap(args, faccN, tap):
    faccN = torch.tensor(faccN)
    tap = torch.tensor(tap)
    tap[faccN < 1-args.tau] = 0
    tap = tap.tolist()
    return tap

def Rap(args, nap, tap):
    rap = []
    length = len(tap[0])
    for j in range(args.algNum):
        rap.append([])
    for i in range(length):
        min_num = 100
        # 查找tap=1里最小的nap
        for j in range(args.algNum):
            if tap[j][i] == 1:
                min_num = min(min_num, nap[j][i])
        # 计算rap
        for j in range(args.algNum):
            if tap[j][i] == 0:
                rap[j].append(100)
            else:
                rap[j].append( nap[j][i] / min_num )
    return rap

def DaKValue(args, nap, tap):
    length = len(nap[0])
    dak = []
    for j in range(args.algNum):
        dak.append([])
    for i in range(length):
        for j in range(args.algNum):
            if tap[j][i] == 0:
                dak[j].append(10000)
            else:
                dak[j].append( nap[j][i] / (args.np+1) )
    return dak

def Rad(args, faccN):
    faccN = torch.tensor(faccN)
    rad = - torch.log( 1-faccN ) / torch.log(torch.tensor(10.))
    rad[torch.isinf(rad)] = 10   #将无穷大的数值转换为10
    return rad.tolist()

class optFunc():
    def listPrintR(self, y, func_list):
        '''
        输出算法1 的rap， dak表现良好的函数
        '''
        opt_list = []
        length = len(y[0])
        y = torch.tensor(y)
        for i in range(length):
            if y[0][i] <= torch.min(y, dim=0).values[i]:
                opt_list.append(func_list[i])
        return opt_list

    def listPrintD(self, y, func_list):
        '''
        输出算法1 的rad表现良好的函数
        '''
        opt_list = []
        length = len(y[0])
        y = torch.tensor(y)
        for i in range(length):
            if y[0][i] >= torch.max(y, dim=0).values[i]:
                opt_list.append(func_list[i])
        return opt_list

    def optfunc(self, rap, dak, rad, func_list):
        '''
        分别输出算法1 的rap，dak，rad表现良好的函数
        '''
        rap_opt = self.listPrintR(rap, func_list)
        dak_opt = self.listPrintR(dak, func_list)
        rad_opt = self.listPrintD(rad, func_list)
        return rap_opt, dak_opt, rad_opt

    def judge_list(self, rap_opt, dak_opt, rad_opt, func_list):
        '''
        分别输出算法1 在rap，rad，dak上表现较差和表现较好的函数名称
        '''
        length = len(func_list)
        badList = []
        goodeq = []
        for i in range(length):
            if func_list[i] in rap_opt and func_list[i] in rad_opt and func_list[i] in dak_opt:
                goodeq.append(func_list[i])
        for i in range(length):
            if func_list[i] not in rap_opt and func_list[i] not in rad_opt and func_list[i] not in dak_opt:
                badList.append(func_list[i])
        return badList, goodeq


class picData():
    '''
    画rap， dak， rad图
    '''
    def drawPic(self, x, y, label, args):
        style = [':', '-', '--', '-.']
        for j in range(args.algNum):
            plt.stairs(y[j], x, linewidth=2, label='alg'+str(j+1), linestyle= style[j%4], baseline=0)
        plt.legend()
        plt.xlabel(label[0])
        plt.ylabel(label[1])
        plt.title('c1={}, c2={}, c3={}'.format(args.c1, args.c2, args.c3))
        plt.show()

    def pic1(self, args, rap):
        x = torch.arange(1, 5, 0.01)
        rap = torch.tensor(rap)
        xsize = x.size()[0]-1
        y = torch.zeros(args.algNum, xsize)
        for i in range(xsize):
            for j in range(args.algNum):
                y[j][i] = torch.sum(rap[j] <= x[i]) * 1. / rap.size()[1]
        label = ['alpha', 'rap']
        self.drawPic(x, y, label, args)
        return x, y

    def pic2(self, args, dak):
        x = torch.arange(1, 61, 1)
        dak = torch.tensor(dak)
        xsize = x.size()[0]-1
        y = torch.zeros(args.algNum, xsize)
        for i in range(xsize):
            for j in range(args.algNum):
                y[j][i] = torch.sum(dak[j] <= x[i]) * 1. / dak.size()[1]
        label = ['k', 'dak']
        self.drawPic(x, y, label, args)
        return x, y

    def pic3(self, args, rad):
        x = torch.arange(0, 11, 0.1)
        xsize = x.size()[0] - 1
        rad = torch.tensor(rad)
        y = torch.zeros(args.algNum, xsize)
        for i in range(xsize):
            for j in range(args.algNum):
                y[j][i] = torch.sum(rad[j] >= x[i]) * 1. / rad.size()[1]
        label = ['a', 'rad']
        self.drawPic(x, y, label, args)
        return x, y


class funcPic():
    '''
    展示各个算法处理问题func的函数值，func选取算法1 表现良好的问题
    '''
    def flabel(self, args, func, func_index, data):
        x = []
        y_labels = []
        for i in range(args.algNum):
            y_labels.append(data[i][func])
        y_labels = self.yprocess(y_labels)
        self.fpic(args, y_labels, func_index)
        return y_labels

    def yprocess(self, y):
        y_new = []
        for j in range(len(y)):
            minimum = y[j][0]
            y_new.append([])
            for i in range(len(y[j])):
                minimum = min(minimum, y[j][i])
                y_new[j].append(minimum)
        return y_new

    def fpic(self, args, y, func_index):
        x = range(args.itr)
        style = [':', '-', '--', '-.']
        for j in range(args.algNum):
            length = min(args.itr, len(y[j]))
            plt.plot(x[0:length], y[j][0:length], linewidth=2, label='alg'+str(j+1), linestyle=style[j%4])
        plt.legend()
        #plt.xlabel(label[0])
        #plt.ylabel(label[1])
        plt.title('c1={}, c2={}, c3={}, j={}'.format(args.c1, args.c2, args.c3, func_index))
        plt.show()

