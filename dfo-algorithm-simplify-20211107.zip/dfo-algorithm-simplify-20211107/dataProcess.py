import torch
import matplotlib.pyplot as plt
import math
import warnings
warnings.filterwarnings('ignore')
from fujian import loadData, preProcess, optValue, f_acc_N
from fujian import Tap, Rad, Rap, DaKValue
from datetime import datetime
date = datetime.now().strftime('%Y-%m-%d %H:%M')


from fujian import picData, optFunc, funcPic

class Arguement():
    def __init__(self):
        self.tau = 0.05
        self.np = 10    # 输入数据的维度
        self.c1 = 1      # 算法1的参数值c1,c2,c3
        self.c2 = 1
        self.c3 = 0.1
        self.algNum = 5   # 算法个数
        self.itr = 500    # 算法1和2的迭代次数
        self.options = [{"maxfev": 500, "tol_f": 1e-28},
                        {"maxfev": 500, "tol_f": 1e-28, "sample_gen": "auto", "verbosity": 0},
                        {"maxfev": 500, "tol_norm_g": 1e-50, "sample_gen": "auto", "verbosity": 0},
                        {"maxfev": 500, "tol_f": 1e-30, "sample_gen": "auto", "verbosity": 0}]



def saveGoodData(args, date, rap, dak, rad, goodNum):
    with open('results/goodresults.txt', 'a+') as fl:
        fl.write('%' + date +'  funcNum is {}, c is [{}, {}, {}], clip is {}, tau is {}, itr is {}, badlist = {} \n'.
                 format(goodNum, args.c1, args.c2, args.c3, args.clip, args.tau, args.itr, args.bad_list))
        fl.write('rap_1 = ' + str(rap) + ';\n')
        fl.write('dak_1 = ' + str(dak) + ';\n')
        fl.write('rad_1 = ' + str(rad) + ';\n')


if __name__ == "__main__":
    args = Arguement()

    # 载入数据
    load_data = loadData()
    data = load_data.loaddata(args)

    '''
        数据预处理
        func_list: 存储函数名称，
        minimum: 存储各个算法训练各个函数的最小值，
        min_index: 存储各个算法训练各个函数出现最小值的索引，
        y_init: 存储各个函数的初始值，
        opt: 各个函数的最优值，即各个函数的f(x*)。
    '''
    func_list, minimum, nap, y_init, tap, opt = preProcess(data, args)

    faccN = f_acc_N(args, minimum, opt, y_init, tap)
    tap = Tap(args, faccN, tap)
    rap = Rap(args, nap, tap)
    dak = DaKValue(args, nap, tap)
    rad = Rad(args, faccN)

    # 保存数据
    with open('results/picdata.txt', 'w') as fl:
        fl.write('\n' + 'rap = {}; \n dak = {}; \nrad = {};'.format(rap, dak, rad))

    # 画图
    # picdata = picData()
    # pic1_x, pic1_y = picdata.pic1(args, rap)
    # pic2_x, pic2_y = picdata.pic2(args, dak)
    # pic3_x, pic3_y = picdata.pic3(args, rad)

    optFunc = optFunc()
    # 判断算法1表现较好的函数名并保存相关问题的函数值
    rap_opt, dak_opt, rad_opt = optFunc.optfunc(rap, dak, rad, func_list)
    badList, goodlist = optFunc.judge_list(rap_opt, dak_opt, rad_opt, func_list)

    funcpic = funcPic()
    num = [7,8,9,10,12]
    for j in num:
        func_index = j
        y = funcpic.flabel(args, goodlist[j], goodlist[j], data)

        # 保存算法1 表现良好的的函数数据
        with open('results/funcItrs.txt', 'a+') as fl:
            fl.write('%func name is {};'.format(goodlist[j]))   # 7,8,9,10,12
            for i in range(args.algNum):
                fl.write('\n' + 'y{} = {};'.format(i, y[i][0:args.itr]))
            fl.write('\n')

